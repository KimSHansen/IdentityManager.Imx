import { ValType, DisplayColumns, ReadWriteExtTypedEntity, TypedEntity, WriteExtTypedEntity, TypedEntityBuilder, InteractiveTypedEntityBuilder, EntityState, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var StatisticAggregateFunction;
(function (StatisticAggregateFunction) {
    StatisticAggregateFunction[StatisticAggregateFunction["None"] = 0] = "None";
    StatisticAggregateFunction[StatisticAggregateFunction["Sum"] = 1] = "Sum";
    StatisticAggregateFunction[StatisticAggregateFunction["Average"] = 2] = "Average";
})(StatisticAggregateFunction || (StatisticAggregateFunction = {}));
var StatisticTimeScaleUnit;
(function (StatisticTimeScaleUnit) {
    StatisticTimeScaleUnit[StatisticTimeScaleUnit["Undefined"] = 0] = "Undefined";
    StatisticTimeScaleUnit[StatisticTimeScaleUnit["Hour"] = 1] = "Hour";
    StatisticTimeScaleUnit[StatisticTimeScaleUnit["Day"] = 2] = "Day";
    StatisticTimeScaleUnit[StatisticTimeScaleUnit["Week"] = 3] = "Week";
    StatisticTimeScaleUnit[StatisticTimeScaleUnit["Month"] = 4] = "Month";
    StatisticTimeScaleUnit[StatisticTimeScaleUnit["Quarter"] = 5] = "Quarter";
    StatisticTimeScaleUnit[StatisticTimeScaleUnit["Year"] = 6] = "Year";
})(StatisticTimeScaleUnit || (StatisticTimeScaleUnit = {}));
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalApplication = new PortalApplicationWrapper(client, translationProvider);
        this.PortalApplicationIdentities = new PortalApplicationIdentitiesWrapper(client, translationProvider);
        this.PortalApplicationIdentitiesbyidentity = new PortalApplicationIdentitiesbyidentityWrapper(client, translationProvider);
        this.PortalApplicationinshop = new PortalApplicationinshopWrapper(client, translationProvider);
        this.PortalApplicationInteractive = new PortalApplicationInteractiveWrapper(client, translationProvider);
        this.PortalApplicationNew = new PortalApplicationNewWrapper(client, translationProvider);
        this.PortalApplicationSqlwizardCandidates = new PortalApplicationSqlwizardCandidatesWrapper(client, translationProvider);
        this.PortalApplicationusesaccount = new PortalApplicationusesaccountWrapper(client, translationProvider);
        this.PortalApplicationusesaccountNew = new PortalApplicationusesaccountNewWrapper(client, translationProvider);
        this.PortalCandidatesAccproductparamcategory = new PortalCandidatesAccproductparamcategoryWrapper(client, translationProvider);
        this.PortalCandidatesAerole = new PortalCandidatesAeroleWrapper(client, translationProvider);
        this.PortalCandidatesAobapplication = new PortalCandidatesAobapplicationWrapper(client, translationProvider);
        this.PortalCandidatesApplication = new PortalCandidatesApplicationWrapper(client, translationProvider);
        this.PortalCandidatesEset = new PortalCandidatesEsetWrapper(client, translationProvider);
        this.PortalCandidatesFunctionalarea = new PortalCandidatesFunctionalareaWrapper(client, translationProvider);
        this.PortalCandidatesOrg = new PortalCandidatesOrgWrapper(client, translationProvider);
        this.PortalCandidatesPerson = new PortalCandidatesPersonWrapper(client, translationProvider);
        this.PortalCandidatesQerassign = new PortalCandidatesQerassignWrapper(client, translationProvider);
        this.PortalCandidatesQerresource = new PortalCandidatesQerresourceWrapper(client, translationProvider);
        this.PortalCandidatesQerreuse = new PortalCandidatesQerreuseWrapper(client, translationProvider);
        this.PortalCandidatesQerreuseus = new PortalCandidatesQerreuseusWrapper(client, translationProvider);
        this.PortalCandidatesQertermsofuse = new PortalCandidatesQertermsofuseWrapper(client, translationProvider);
        this.PortalCandidatesRpsreport = new PortalCandidatesRpsreportWrapper(client, translationProvider);
        this.PortalCandidatesTsbaccountdef = new PortalCandidatesTsbaccountdefWrapper(client, translationProvider);
        this.PortalCandidatesUnsaccountb = new PortalCandidatesUnsaccountbWrapper(client, translationProvider);
        this.PortalCandidatesUnsgroup = new PortalCandidatesUnsgroupWrapper(client, translationProvider);
        this.PortalCandidatesUnsroot = new PortalCandidatesUnsrootWrapper(client, translationProvider);
        this.PortalEntitlement = new PortalEntitlementWrapper(client, translationProvider);
        this.PortalEntitlementcandidatesEset = new PortalEntitlementcandidatesEsetWrapper(client, translationProvider);
        this.PortalEntitlementcandidatesQerresource = new PortalEntitlementcandidatesQerresourceWrapper(client, translationProvider);
        this.PortalEntitlementcandidatesRpsreport = new PortalEntitlementcandidatesRpsreportWrapper(client, translationProvider);
        this.PortalEntitlementcandidatesTsbaccountdef = new PortalEntitlementcandidatesTsbaccountdefWrapper(client, translationProvider);
        this.PortalEntitlementcandidatesUnsgroup = new PortalEntitlementcandidatesUnsgroupWrapper(client, translationProvider);
        this.PortalEntitlementInteractive = new PortalEntitlementInteractiveWrapper(client, translationProvider);
        this.PortalEntitlementServiceitem = new PortalEntitlementServiceitemWrapper(client, translationProvider);
        this.PortalEntitlementSystemrole = new PortalEntitlementSystemroleWrapper(client, translationProvider);
        this.PortalOwners = new PortalOwnersWrapper(client, translationProvider);
        this.PortalShops = new PortalShopsWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalApplication = /** @class */ (function (_super) {
    __extends(PortalApplication, _super);
    function PortalApplication() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ActivationDate = _this.GetEntityValue('ActivationDate');
        _this.ApplicationEnvironment = _this.GetEntityValue('ApplicationEnvironment');
        _this.ApplicationWebURL = _this.GetEntityValue('ApplicationWebURL');
        _this.AuthenticationRoot = _this.GetEntityValue('AuthenticationRoot');
        _this.Description = _this.GetEntityValue('Description');
        _this.Ident_AOBApplication = _this.GetEntityValue('Ident_AOBApplication');
        _this.IsAuthenticationIntegrated = _this.GetEntityValue('IsAuthenticationIntegrated');
        _this.IsFederationEnabled = _this.GetEntityValue('IsFederationEnabled');
        _this.IsInActive = _this.GetEntityValue('IsInActive');
        _this.IsMultiFactorEnabled = _this.GetEntityValue('IsMultiFactorEnabled');
        _this.IsSSOEnabled = _this.GetEntityValue('IsSSOEnabled');
        _this.JPegPhoto = _this.GetEntityValue('JPegPhoto');
        _this.NextRunDate = _this.GetEntityValue('NextRunDate');
        _this.PurchasedLicenses = _this.GetEntityValue('PurchasedLicenses');
        _this.RiskIndex = _this.GetEntityValue('RiskIndex');
        _this.SSORedirectionUrl = _this.GetEntityValue('SSORedirectionUrl');
        _this.UID_AERoleApprover = _this.GetEntityValue('UID_AERoleApprover');
        _this.UID_AERoleOwner = _this.GetEntityValue('UID_AERoleOwner');
        _this.UID_AOBApplication = _this.GetEntityValue('UID_AOBApplication');
        _this.UID_FunctionalArea = _this.GetEntityValue('UID_FunctionalArea');
        _this.UID_ITShopSrcBT = _this.GetEntityValue('UID_ITShopSrcBT');
        _this.UID_PersonHead = _this.GetEntityValue('UID_PersonHead');
        _this.WhereClause = _this.GetEntityValue('WhereClause');
        _this.WhereClauseAddOn = _this.GetEntityValue('WhereClauseAddOn');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XTouched = _this.GetEntityValue('XTouched');
        _this.XUserInserted = _this.GetEntityValue('XUserInserted');
        _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
        _this.HasKpiIssues = _this.GetEntityValue('HasKpiIssues');
        _this.UID_AccProductGroup = _this.GetEntityValue('UID_AccProductGroup');
        _this.AuthenticationRootHelper = _this.GetEntityValue('AuthenticationRootHelper');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplication.GetEntitySchema = function () {
        var columns = {
            'ActivationDate': {
                ColumnName: 'ActivationDate',
                Type: ValType.Date,
                IsReadOnly: false,
            },
            'ApplicationEnvironment': {
                ColumnName: 'ApplicationEnvironment',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'ApplicationWebURL': {
                ColumnName: 'ApplicationWebURL',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'AuthenticationRoot': {
                ColumnName: 'AuthenticationRoot',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Description': {
                ColumnName: 'Description',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'Ident_AOBApplication': {
                ColumnName: 'Ident_AOBApplication',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'IsAuthenticationIntegrated': {
                ColumnName: 'IsAuthenticationIntegrated',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsFederationEnabled': {
                ColumnName: 'IsFederationEnabled',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsInActive': {
                ColumnName: 'IsInActive',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsMultiFactorEnabled': {
                ColumnName: 'IsMultiFactorEnabled',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsSSOEnabled': {
                ColumnName: 'IsSSOEnabled',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'JPegPhoto': {
                ColumnName: 'JPegPhoto',
                Type: ValType.Binary,
                IsReadOnly: false,
            },
            'NextRunDate': {
                ColumnName: 'NextRunDate',
                Type: ValType.Date,
                IsReadOnly: false,
            },
            'PurchasedLicenses': {
                ColumnName: 'PurchasedLicenses',
                Type: ValType.Int,
                IsReadOnly: false,
            },
            'RiskIndex': {
                ColumnName: 'RiskIndex',
                Type: ValType.Double,
                IsReadOnly: false,
            },
            'SSORedirectionUrl': {
                ColumnName: 'SSORedirectionUrl',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'UID_AERoleApprover': {
                ColumnName: 'UID_AERoleApprover',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AERoleOwner': {
                ColumnName: 'UID_AERoleOwner',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AOBApplication': {
                ColumnName: 'UID_AOBApplication',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_FunctionalArea': {
                ColumnName: 'UID_FunctionalArea',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_ITShopSrcBT': {
                ColumnName: 'UID_ITShopSrcBT',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_PersonHead': {
                ColumnName: 'UID_PersonHead',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'WhereClause': {
                ColumnName: 'WhereClause',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'WhereClauseAddOn': {
                ColumnName: 'WhereClauseAddOn',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XDateUpdated': {
                ColumnName: 'XDateUpdated',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XTouched': {
                ColumnName: 'XTouched',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserInserted': {
                ColumnName: 'XUserInserted',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserUpdated': {
                ColumnName: 'XUserUpdated',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'HasKpiIssues': {
                ColumnName: 'HasKpiIssues',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'UID_AccProductGroup': {
                ColumnName: 'UID_AccProductGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'AuthenticationRootHelper': {
                ColumnName: 'AuthenticationRootHelper',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AOBApplication', Columns: columns };
    };
    return PortalApplication;
}(ReadWriteExtTypedEntity));
/** @deprecated Use the PortalApplication type. */
var PortalApplicationInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationInteractive, _super);
    function PortalApplicationInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationInteractive;
}(PortalApplication));
var PortalApplicationIdentities = /** @class */ (function (_super) {
    __extends(PortalApplicationIdentities, _super);
    function PortalApplicationIdentities() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplicationIdentities.GetEntitySchema = function () {
        var columns = {
            'DefaultEmailAddress': {
                ColumnName: 'DefaultEmailAddress',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Person', Columns: columns };
    };
    return PortalApplicationIdentities;
}(TypedEntity));
/** @deprecated Use the PortalApplicationIdentities type. */
var PortalApplicationIdentitiesInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationIdentitiesInteractive, _super);
    function PortalApplicationIdentitiesInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationIdentitiesInteractive;
}(PortalApplicationIdentities));
var PortalApplicationIdentitiesbyidentity = /** @class */ (function (_super) {
    __extends(PortalApplicationIdentitiesbyidentity, _super);
    function PortalApplicationIdentitiesbyidentity() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ObjectKeyElement = _this.GetEntityValue('ObjectKeyElement');
        _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.IsRequestCancellable = _this.GetEntityValue('IsRequestCancellable');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplicationIdentitiesbyidentity.GetEntitySchema = function () {
        var columns = {
            'ObjectKeyElement': {
                ColumnName: 'ObjectKeyElement',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_PersonWantsOrg': {
                ColumnName: 'UID_PersonWantsOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsRequestCancellable': {
                ColumnName: 'IsRequestCancellable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AOBEntitlement', Columns: columns };
    };
    return PortalApplicationIdentitiesbyidentity;
}(TypedEntity));
/** @deprecated Use the PortalApplicationIdentitiesbyidentity type. */
var PortalApplicationIdentitiesbyidentityInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationIdentitiesbyidentityInteractive, _super);
    function PortalApplicationIdentitiesbyidentityInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationIdentitiesbyidentityInteractive;
}(PortalApplicationIdentitiesbyidentity));
var PortalApplicationinshop = /** @class */ (function (_super) {
    __extends(PortalApplicationinshop, _super);
    function PortalApplicationinshop() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplicationinshop.GetEntitySchema = function () {
        var columns = {
            'UID_ITShopOrg': {
                ColumnName: 'UID_ITShopOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ITShopOrg', Columns: columns };
    };
    return PortalApplicationinshop;
}(TypedEntity));
/** @deprecated Use the PortalApplicationinshop type. */
var PortalApplicationinshopInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationinshopInteractive, _super);
    function PortalApplicationinshopInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationinshopInteractive;
}(PortalApplicationinshop));
var PortalApplicationNew = /** @class */ (function (_super) {
    __extends(PortalApplicationNew, _super);
    function PortalApplicationNew() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ActivationDate = _this.GetEntityValue('ActivationDate');
        _this.ApplicationEnvironment = _this.GetEntityValue('ApplicationEnvironment');
        _this.ApplicationWebURL = _this.GetEntityValue('ApplicationWebURL');
        _this.AuthenticationRoot = _this.GetEntityValue('AuthenticationRoot');
        _this.Description = _this.GetEntityValue('Description');
        _this.Ident_AOBApplication = _this.GetEntityValue('Ident_AOBApplication');
        _this.IsAuthenticationIntegrated = _this.GetEntityValue('IsAuthenticationIntegrated');
        _this.IsFederationEnabled = _this.GetEntityValue('IsFederationEnabled');
        _this.IsInActive = _this.GetEntityValue('IsInActive');
        _this.IsMultiFactorEnabled = _this.GetEntityValue('IsMultiFactorEnabled');
        _this.IsSSOEnabled = _this.GetEntityValue('IsSSOEnabled');
        _this.JPegPhoto = _this.GetEntityValue('JPegPhoto');
        _this.NextRunDate = _this.GetEntityValue('NextRunDate');
        _this.PurchasedLicenses = _this.GetEntityValue('PurchasedLicenses');
        _this.RiskIndex = _this.GetEntityValue('RiskIndex');
        _this.SSORedirectionUrl = _this.GetEntityValue('SSORedirectionUrl');
        _this.UID_AERoleApprover = _this.GetEntityValue('UID_AERoleApprover');
        _this.UID_AERoleOwner = _this.GetEntityValue('UID_AERoleOwner');
        _this.UID_AOBApplication = _this.GetEntityValue('UID_AOBApplication');
        _this.UID_FunctionalArea = _this.GetEntityValue('UID_FunctionalArea');
        _this.UID_ITShopSrcBT = _this.GetEntityValue('UID_ITShopSrcBT');
        _this.UID_PersonHead = _this.GetEntityValue('UID_PersonHead');
        _this.WhereClause = _this.GetEntityValue('WhereClause');
        _this.WhereClauseAddOn = _this.GetEntityValue('WhereClauseAddOn');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XTouched = _this.GetEntityValue('XTouched');
        _this.XUserInserted = _this.GetEntityValue('XUserInserted');
        _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
        _this.UID_AccProductGroup = _this.GetEntityValue('UID_AccProductGroup');
        _this.AuthenticationRootHelper = _this.GetEntityValue('AuthenticationRootHelper');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplicationNew.GetEntitySchema = function () {
        var columns = {
            'ActivationDate': {
                ColumnName: 'ActivationDate',
                Type: ValType.Date,
                IsReadOnly: false,
            },
            'ApplicationEnvironment': {
                ColumnName: 'ApplicationEnvironment',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'ApplicationWebURL': {
                ColumnName: 'ApplicationWebURL',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'AuthenticationRoot': {
                ColumnName: 'AuthenticationRoot',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Description': {
                ColumnName: 'Description',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'Ident_AOBApplication': {
                ColumnName: 'Ident_AOBApplication',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'IsAuthenticationIntegrated': {
                ColumnName: 'IsAuthenticationIntegrated',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsFederationEnabled': {
                ColumnName: 'IsFederationEnabled',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsInActive': {
                ColumnName: 'IsInActive',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsMultiFactorEnabled': {
                ColumnName: 'IsMultiFactorEnabled',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsSSOEnabled': {
                ColumnName: 'IsSSOEnabled',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'JPegPhoto': {
                ColumnName: 'JPegPhoto',
                Type: ValType.Binary,
                IsReadOnly: false,
            },
            'NextRunDate': {
                ColumnName: 'NextRunDate',
                Type: ValType.Date,
                IsReadOnly: false,
            },
            'PurchasedLicenses': {
                ColumnName: 'PurchasedLicenses',
                Type: ValType.Int,
                IsReadOnly: false,
            },
            'RiskIndex': {
                ColumnName: 'RiskIndex',
                Type: ValType.Double,
                IsReadOnly: false,
            },
            'SSORedirectionUrl': {
                ColumnName: 'SSORedirectionUrl',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'UID_AERoleApprover': {
                ColumnName: 'UID_AERoleApprover',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AERoleOwner': {
                ColumnName: 'UID_AERoleOwner',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AOBApplication': {
                ColumnName: 'UID_AOBApplication',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_FunctionalArea': {
                ColumnName: 'UID_FunctionalArea',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_ITShopSrcBT': {
                ColumnName: 'UID_ITShopSrcBT',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_PersonHead': {
                ColumnName: 'UID_PersonHead',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'WhereClause': {
                ColumnName: 'WhereClause',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'WhereClauseAddOn': {
                ColumnName: 'WhereClauseAddOn',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XDateUpdated': {
                ColumnName: 'XDateUpdated',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XTouched': {
                ColumnName: 'XTouched',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserInserted': {
                ColumnName: 'XUserInserted',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserUpdated': {
                ColumnName: 'XUserUpdated',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AccProductGroup': {
                ColumnName: 'UID_AccProductGroup',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'AuthenticationRootHelper': {
                ColumnName: 'AuthenticationRootHelper',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AOBApplication', Columns: columns };
    };
    return PortalApplicationNew;
}(TypedEntity));
/** @deprecated Use the PortalApplicationNew type. */
var PortalApplicationNewInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationNewInteractive, _super);
    function PortalApplicationNewInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationNewInteractive;
}(PortalApplicationNew));
var PortalApplicationSqlwizardCandidates = /** @class */ (function (_super) {
    __extends(PortalApplicationSqlwizardCandidates, _super);
    function PortalApplicationSqlwizardCandidates() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplicationSqlwizardCandidates.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'non_static_table', Columns: columns };
    };
    return PortalApplicationSqlwizardCandidates;
}(TypedEntity));
/** @deprecated Use the PortalApplicationSqlwizardCandidates type. */
var PortalApplicationSqlwizardCandidatesInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationSqlwizardCandidatesInteractive, _super);
    function PortalApplicationSqlwizardCandidatesInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationSqlwizardCandidatesInteractive;
}(PortalApplicationSqlwizardCandidates));
var PortalApplicationusesaccount = /** @class */ (function (_super) {
    __extends(PortalApplicationusesaccount, _super);
    function PortalApplicationusesaccount() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AOBApplication = _this.GetEntityValue('UID_AOBApplication');
        _this.UID_AOBAppUsesAccount = _this.GetEntityValue('UID_AOBAppUsesAccount');
        _this.ObjectKeyAccount = _this.GetEntityValue('ObjectKeyAccount');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplicationusesaccount.GetEntitySchema = function () {
        var columns = {
            'UID_AOBApplication': {
                ColumnName: 'UID_AOBApplication',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AOBAppUsesAccount': {
                ColumnName: 'UID_AOBAppUsesAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAccount': {
                ColumnName: 'ObjectKeyAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AOBAppUsesAccount', Columns: columns };
    };
    return PortalApplicationusesaccount;
}(TypedEntity));
/** @deprecated Use the PortalApplicationusesaccount type. */
var PortalApplicationusesaccountInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationusesaccountInteractive, _super);
    function PortalApplicationusesaccountInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationusesaccountInteractive;
}(PortalApplicationusesaccount));
var PortalApplicationusesaccountNew = /** @class */ (function (_super) {
    __extends(PortalApplicationusesaccountNew, _super);
    function PortalApplicationusesaccountNew() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ObjectKeyAccount = _this.GetEntityValue('ObjectKeyAccount');
        _this.UID_AOBApplication = _this.GetEntityValue('UID_AOBApplication');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalApplicationusesaccountNew.GetEntitySchema = function () {
        var columns = {
            'ObjectKeyAccount': {
                ColumnName: 'ObjectKeyAccount',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AOBApplication': {
                ColumnName: 'UID_AOBApplication',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AOBAppUsesAccount', Columns: columns };
    };
    return PortalApplicationusesaccountNew;
}(TypedEntity));
/** @deprecated Use the PortalApplicationusesaccountNew type. */
var PortalApplicationusesaccountNewInteractive = /** @class */ (function (_super) {
    __extends(PortalApplicationusesaccountNewInteractive, _super);
    function PortalApplicationusesaccountNewInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalApplicationusesaccountNewInteractive;
}(PortalApplicationusesaccountNew));
var PortalCandidatesAccproductparamcategory = /** @class */ (function (_super) {
    __extends(PortalCandidatesAccproductparamcategory, _super);
    function PortalCandidatesAccproductparamcategory() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_AccProductParamCategory = _this.GetEntityValue('UID_AccProductParamCategory');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesAccproductparamcategory.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AccProductParamCategory': {
                ColumnName: 'UID_AccProductParamCategory',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AccProductParamCategory', Columns: columns };
    };
    return PortalCandidatesAccproductparamcategory;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesAccproductparamcategory type. */
var PortalCandidatesAccproductparamcategoryInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesAccproductparamcategoryInteractive, _super);
    function PortalCandidatesAccproductparamcategoryInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesAccproductparamcategoryInteractive;
}(PortalCandidatesAccproductparamcategory));
var PortalCandidatesAerole = /** @class */ (function (_super) {
    __extends(PortalCandidatesAerole, _super);
    function PortalCandidatesAerole() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_AERole = _this.GetEntityValue('UID_AERole');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesAerole.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AERole': {
                ColumnName: 'UID_AERole',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AERole', Columns: columns };
    };
    return PortalCandidatesAerole;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesAerole type. */
var PortalCandidatesAeroleInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesAeroleInteractive, _super);
    function PortalCandidatesAeroleInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesAeroleInteractive;
}(PortalCandidatesAerole));
var PortalCandidatesAobapplication = /** @class */ (function (_super) {
    __extends(PortalCandidatesAobapplication, _super);
    function PortalCandidatesAobapplication() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_AOBApplication = _this.GetEntityValue('UID_AOBApplication');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesAobapplication.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AOBApplication': {
                ColumnName: 'UID_AOBApplication',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AOBApplication', Columns: columns };
    };
    return PortalCandidatesAobapplication;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesAobapplication type. */
var PortalCandidatesAobapplicationInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesAobapplicationInteractive, _super);
    function PortalCandidatesAobapplicationInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesAobapplicationInteractive;
}(PortalCandidatesAobapplication));
var PortalCandidatesApplication = /** @class */ (function (_super) {
    __extends(PortalCandidatesApplication, _super);
    function PortalCandidatesApplication() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_Application = _this.GetEntityValue('UID_Application');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesApplication.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Application': {
                ColumnName: 'UID_Application',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Application', Columns: columns };
    };
    return PortalCandidatesApplication;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesApplication type. */
var PortalCandidatesApplicationInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesApplicationInteractive, _super);
    function PortalCandidatesApplicationInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesApplicationInteractive;
}(PortalCandidatesApplication));
var PortalCandidatesEset = /** @class */ (function (_super) {
    __extends(PortalCandidatesEset, _super);
    function PortalCandidatesEset() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_ESet = _this.GetEntityValue('UID_ESet');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesEset.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_ESet': {
                ColumnName: 'UID_ESet',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ESet', Columns: columns };
    };
    return PortalCandidatesEset;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesEset type. */
var PortalCandidatesEsetInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesEsetInteractive, _super);
    function PortalCandidatesEsetInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesEsetInteractive;
}(PortalCandidatesEset));
var PortalCandidatesFunctionalarea = /** @class */ (function (_super) {
    __extends(PortalCandidatesFunctionalarea, _super);
    function PortalCandidatesFunctionalarea() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_FunctionalArea = _this.GetEntityValue('UID_FunctionalArea');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesFunctionalarea.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_FunctionalArea': {
                ColumnName: 'UID_FunctionalArea',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'FunctionalArea', Columns: columns };
    };
    return PortalCandidatesFunctionalarea;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesFunctionalarea type. */
var PortalCandidatesFunctionalareaInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesFunctionalareaInteractive, _super);
    function PortalCandidatesFunctionalareaInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesFunctionalareaInteractive;
}(PortalCandidatesFunctionalarea));
var PortalCandidatesOrg = /** @class */ (function (_super) {
    __extends(PortalCandidatesOrg, _super);
    function PortalCandidatesOrg() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_Org = _this.GetEntityValue('UID_Org');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesOrg.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Org': {
                ColumnName: 'UID_Org',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Org', Columns: columns };
    };
    return PortalCandidatesOrg;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesOrg type. */
var PortalCandidatesOrgInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesOrgInteractive, _super);
    function PortalCandidatesOrgInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesOrgInteractive;
}(PortalCandidatesOrg));
var PortalCandidatesPerson = /** @class */ (function (_super) {
    __extends(PortalCandidatesPerson, _super);
    function PortalCandidatesPerson() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesPerson.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'DefaultEmailAddress': {
                ColumnName: 'DefaultEmailAddress',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Person', Columns: columns };
    };
    return PortalCandidatesPerson;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesPerson type. */
var PortalCandidatesPersonInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesPersonInteractive, _super);
    function PortalCandidatesPersonInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesPersonInteractive;
}(PortalCandidatesPerson));
var PortalCandidatesQerassign = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerassign, _super);
    function PortalCandidatesQerassign() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_QERAssign = _this.GetEntityValue('UID_QERAssign');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesQerassign.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERAssign': {
                ColumnName: 'UID_QERAssign',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERAssign', Columns: columns };
    };
    return PortalCandidatesQerassign;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesQerassign type. */
var PortalCandidatesQerassignInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerassignInteractive, _super);
    function PortalCandidatesQerassignInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesQerassignInteractive;
}(PortalCandidatesQerassign));
var PortalCandidatesQerresource = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerresource, _super);
    function PortalCandidatesQerresource() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_QERResource = _this.GetEntityValue('UID_QERResource');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesQerresource.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERResource': {
                ColumnName: 'UID_QERResource',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERResource', Columns: columns };
    };
    return PortalCandidatesQerresource;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesQerresource type. */
var PortalCandidatesQerresourceInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerresourceInteractive, _super);
    function PortalCandidatesQerresourceInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesQerresourceInteractive;
}(PortalCandidatesQerresource));
var PortalCandidatesQerreuse = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerreuse, _super);
    function PortalCandidatesQerreuse() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_QERReuse = _this.GetEntityValue('UID_QERReuse');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesQerreuse.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERReuse': {
                ColumnName: 'UID_QERReuse',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERReuse', Columns: columns };
    };
    return PortalCandidatesQerreuse;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesQerreuse type. */
var PortalCandidatesQerreuseInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerreuseInteractive, _super);
    function PortalCandidatesQerreuseInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesQerreuseInteractive;
}(PortalCandidatesQerreuse));
var PortalCandidatesQerreuseus = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerreuseus, _super);
    function PortalCandidatesQerreuseus() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_QERReuseUS = _this.GetEntityValue('UID_QERReuseUS');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesQerreuseus.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERReuseUS': {
                ColumnName: 'UID_QERReuseUS',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERReuseUS', Columns: columns };
    };
    return PortalCandidatesQerreuseus;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesQerreuseus type. */
var PortalCandidatesQerreuseusInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesQerreuseusInteractive, _super);
    function PortalCandidatesQerreuseusInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesQerreuseusInteractive;
}(PortalCandidatesQerreuseus));
var PortalCandidatesQertermsofuse = /** @class */ (function (_super) {
    __extends(PortalCandidatesQertermsofuse, _super);
    function PortalCandidatesQertermsofuse() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_QERTermsOfUse = _this.GetEntityValue('UID_QERTermsOfUse');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesQertermsofuse.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_QERTermsOfUse': {
                ColumnName: 'UID_QERTermsOfUse',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERTermsOfUse', Columns: columns };
    };
    return PortalCandidatesQertermsofuse;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesQertermsofuse type. */
var PortalCandidatesQertermsofuseInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesQertermsofuseInteractive, _super);
    function PortalCandidatesQertermsofuseInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesQertermsofuseInteractive;
}(PortalCandidatesQertermsofuse));
var PortalCandidatesRpsreport = /** @class */ (function (_super) {
    __extends(PortalCandidatesRpsreport, _super);
    function PortalCandidatesRpsreport() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_RPSReport = _this.GetEntityValue('UID_RPSReport');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesRpsreport.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_RPSReport': {
                ColumnName: 'UID_RPSReport',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'RPSReport', Columns: columns };
    };
    return PortalCandidatesRpsreport;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesRpsreport type. */
var PortalCandidatesRpsreportInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesRpsreportInteractive, _super);
    function PortalCandidatesRpsreportInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesRpsreportInteractive;
}(PortalCandidatesRpsreport));
var PortalCandidatesTsbaccountdef = /** @class */ (function (_super) {
    __extends(PortalCandidatesTsbaccountdef, _super);
    function PortalCandidatesTsbaccountdef() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_TSBAccountDef = _this.GetEntityValue('UID_TSBAccountDef');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesTsbaccountdef.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_TSBAccountDef': {
                ColumnName: 'UID_TSBAccountDef',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'TSBAccountDef', Columns: columns };
    };
    return PortalCandidatesTsbaccountdef;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesTsbaccountdef type. */
var PortalCandidatesTsbaccountdefInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesTsbaccountdefInteractive, _super);
    function PortalCandidatesTsbaccountdefInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesTsbaccountdefInteractive;
}(PortalCandidatesTsbaccountdef));
var PortalCandidatesUnsaccountb = /** @class */ (function (_super) {
    __extends(PortalCandidatesUnsaccountb, _super);
    function PortalCandidatesUnsaccountb() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_UNSAccountB = _this.GetEntityValue('UID_UNSAccountB');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesUnsaccountb.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSAccountB': {
                ColumnName: 'UID_UNSAccountB',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'UNSAccountB', Columns: columns };
    };
    return PortalCandidatesUnsaccountb;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesUnsaccountb type. */
var PortalCandidatesUnsaccountbInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesUnsaccountbInteractive, _super);
    function PortalCandidatesUnsaccountbInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesUnsaccountbInteractive;
}(PortalCandidatesUnsaccountb));
var PortalCandidatesUnsgroup = /** @class */ (function (_super) {
    __extends(PortalCandidatesUnsgroup, _super);
    function PortalCandidatesUnsgroup() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_UNSGroup = _this.GetEntityValue('UID_UNSGroup');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesUnsgroup.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroup': {
                ColumnName: 'UID_UNSGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'UNSGroup', Columns: columns };
    };
    return PortalCandidatesUnsgroup;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesUnsgroup type. */
var PortalCandidatesUnsgroupInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesUnsgroupInteractive, _super);
    function PortalCandidatesUnsgroupInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesUnsgroupInteractive;
}(PortalCandidatesUnsgroup));
var PortalCandidatesUnsroot = /** @class */ (function (_super) {
    __extends(PortalCandidatesUnsroot, _super);
    function PortalCandidatesUnsroot() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalCandidatesUnsroot.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSRoot': {
                ColumnName: 'UID_UNSRoot',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'UNSRoot', Columns: columns };
    };
    return PortalCandidatesUnsroot;
}(TypedEntity));
/** @deprecated Use the PortalCandidatesUnsroot type. */
var PortalCandidatesUnsrootInteractive = /** @class */ (function (_super) {
    __extends(PortalCandidatesUnsrootInteractive, _super);
    function PortalCandidatesUnsrootInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalCandidatesUnsrootInteractive;
}(PortalCandidatesUnsroot));
var PortalEntitlement = /** @class */ (function (_super) {
    __extends(PortalEntitlement, _super);
    function PortalEntitlement() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ActivationDate = _this.GetEntityValue('ActivationDate');
        _this.Description = _this.GetEntityValue('Description');
        _this.Ident_AOBEntitlement = _this.GetEntityValue('Ident_AOBEntitlement');
        _this.IsDynamic = _this.GetEntityValue('IsDynamic');
        _this.IsInActive = _this.GetEntityValue('IsInActive');
        _this.JPegPhoto = _this.GetEntityValue('JPegPhoto');
        _this.ObjectKeyAdditionalApprover = _this.GetEntityValue('ObjectKeyAdditionalApprover');
        _this.ObjectKeyElement = _this.GetEntityValue('ObjectKeyElement');
        _this.UID_AERoleOwner = _this.GetEntityValue('UID_AERoleOwner');
        _this.UID_AOBApplication = _this.GetEntityValue('UID_AOBApplication');
        _this.UID_AOBEntitlement = _this.GetEntityValue('UID_AOBEntitlement');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XTouched = _this.GetEntityValue('XTouched');
        _this.XUserInserted = _this.GetEntityValue('XUserInserted');
        _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
        _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
        _this.IsOwnerOrAdmin = _this.GetEntityValue('IsOwnerOrAdmin');
        _this.IsOutlierAssignment = _this.GetEntityValue('IsOutlierAssignment');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlement.GetEntitySchema = function () {
        var columns = {
            'ActivationDate': {
                ColumnName: 'ActivationDate',
                Type: ValType.Date,
                IsReadOnly: false,
            },
            'Description': {
                ColumnName: 'Description',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'Ident_AOBEntitlement': {
                ColumnName: 'Ident_AOBEntitlement',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'IsDynamic': {
                ColumnName: 'IsDynamic',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsInActive': {
                ColumnName: 'IsInActive',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'JPegPhoto': {
                ColumnName: 'JPegPhoto',
                Type: ValType.Binary,
                IsReadOnly: true,
            },
            'ObjectKeyAdditionalApprover': {
                ColumnName: 'ObjectKeyAdditionalApprover',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'ObjectKeyElement': {
                ColumnName: 'ObjectKeyElement',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AERoleOwner': {
                ColumnName: 'UID_AERoleOwner',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AOBApplication': {
                ColumnName: 'UID_AOBApplication',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AOBEntitlement': {
                ColumnName: 'UID_AOBEntitlement',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XDateUpdated': {
                ColumnName: 'XDateUpdated',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XTouched': {
                ColumnName: 'XTouched',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserInserted': {
                ColumnName: 'XUserInserted',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XUserUpdated': {
                ColumnName: 'XUserUpdated',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AccProduct': {
                ColumnName: 'UID_AccProduct',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsOwnerOrAdmin': {
                ColumnName: 'IsOwnerOrAdmin',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsOutlierAssignment': {
                ColumnName: 'IsOutlierAssignment',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AOBEntitlement', Columns: columns };
    };
    return PortalEntitlement;
}(TypedEntity));
/** @deprecated Use the PortalEntitlement type. */
var PortalEntitlementInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementInteractive, _super);
    function PortalEntitlementInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementInteractive;
}(PortalEntitlement));
var PortalEntitlementcandidatesEset = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesEset, _super);
    function PortalEntitlementcandidatesEset() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlementcandidatesEset.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ESet', Columns: columns };
    };
    return PortalEntitlementcandidatesEset;
}(TypedEntity));
/** @deprecated Use the PortalEntitlementcandidatesEset type. */
var PortalEntitlementcandidatesEsetInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesEsetInteractive, _super);
    function PortalEntitlementcandidatesEsetInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementcandidatesEsetInteractive;
}(PortalEntitlementcandidatesEset));
var PortalEntitlementcandidatesQerresource = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesQerresource, _super);
    function PortalEntitlementcandidatesQerresource() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlementcandidatesQerresource.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'QERResource', Columns: columns };
    };
    return PortalEntitlementcandidatesQerresource;
}(TypedEntity));
/** @deprecated Use the PortalEntitlementcandidatesQerresource type. */
var PortalEntitlementcandidatesQerresourceInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesQerresourceInteractive, _super);
    function PortalEntitlementcandidatesQerresourceInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementcandidatesQerresourceInteractive;
}(PortalEntitlementcandidatesQerresource));
var PortalEntitlementcandidatesRpsreport = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesRpsreport, _super);
    function PortalEntitlementcandidatesRpsreport() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlementcandidatesRpsreport.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'RPSReport', Columns: columns };
    };
    return PortalEntitlementcandidatesRpsreport;
}(TypedEntity));
/** @deprecated Use the PortalEntitlementcandidatesRpsreport type. */
var PortalEntitlementcandidatesRpsreportInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesRpsreportInteractive, _super);
    function PortalEntitlementcandidatesRpsreportInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementcandidatesRpsreportInteractive;
}(PortalEntitlementcandidatesRpsreport));
var PortalEntitlementcandidatesTsbaccountdef = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesTsbaccountdef, _super);
    function PortalEntitlementcandidatesTsbaccountdef() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlementcandidatesTsbaccountdef.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'TSBAccountDef', Columns: columns };
    };
    return PortalEntitlementcandidatesTsbaccountdef;
}(TypedEntity));
/** @deprecated Use the PortalEntitlementcandidatesTsbaccountdef type. */
var PortalEntitlementcandidatesTsbaccountdefInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesTsbaccountdefInteractive, _super);
    function PortalEntitlementcandidatesTsbaccountdefInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementcandidatesTsbaccountdefInteractive;
}(PortalEntitlementcandidatesTsbaccountdef));
var PortalEntitlementcandidatesUnsgroup = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesUnsgroup, _super);
    function PortalEntitlementcandidatesUnsgroup() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.CanonicalName = _this.GetEntityValue('CanonicalName');
        _this.Description = _this.GetEntityValue('Description');
        _this.UID_UNSRoot = _this.GetEntityValue('UID_UNSRoot');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlementcandidatesUnsgroup.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'CanonicalName': {
                ColumnName: 'CanonicalName',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Description': {
                ColumnName: 'Description',
                Type: ValType.Text,
                IsReadOnly: true,
            },
            'UID_UNSRoot': {
                ColumnName: 'UID_UNSRoot',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'UNSGroup', Columns: columns };
    };
    return PortalEntitlementcandidatesUnsgroup;
}(TypedEntity));
/** @deprecated Use the PortalEntitlementcandidatesUnsgroup type. */
var PortalEntitlementcandidatesUnsgroupInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementcandidatesUnsgroupInteractive, _super);
    function PortalEntitlementcandidatesUnsgroupInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementcandidatesUnsgroupInteractive;
}(PortalEntitlementcandidatesUnsgroup));
var PortalEntitlementServiceitem = /** @class */ (function (_super) {
    __extends(PortalEntitlementServiceitem, _super);
    function PortalEntitlementServiceitem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Description = _this.GetEntityValue('Description');
        _this.Ident_AccProduct = _this.GetEntityValue('Ident_AccProduct');
        _this.IsApproveRequiresMfa = _this.GetEntityValue('IsApproveRequiresMfa');
        _this.IsInActive = _this.GetEntityValue('IsInActive');
        _this.JPegPhoto = _this.GetEntityValue('JPegPhoto');
        _this.MaxValidDays = _this.GetEntityValue('MaxValidDays');
        _this.ProductURL = _this.GetEntityValue('ProductURL');
        _this.SortOrder = _this.GetEntityValue('SortOrder');
        _this.UID_AccProductGroup = _this.GetEntityValue('UID_AccProductGroup');
        _this.UID_AccProductParamCategory = _this.GetEntityValue('UID_AccProductParamCategory');
        _this.UID_FunctionalArea = _this.GetEntityValue('UID_FunctionalArea');
        _this.UID_OrgAttestator = _this.GetEntityValue('UID_OrgAttestator');
        _this.UID_OrgRuler = _this.GetEntityValue('UID_OrgRuler');
        _this.UID_PWODecisionMethod = _this.GetEntityValue('UID_PWODecisionMethod');
        _this.UID_QERTermsOfUse = _this.GetEntityValue('UID_QERTermsOfUse');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlementServiceitem.GetEntitySchema = function () {
        var columns = {
            'Description': {
                ColumnName: 'Description',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'Ident_AccProduct': {
                ColumnName: 'Ident_AccProduct',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'IsApproveRequiresMfa': {
                ColumnName: 'IsApproveRequiresMfa',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'IsInActive': {
                ColumnName: 'IsInActive',
                Type: ValType.Bool,
                IsReadOnly: false,
            },
            'JPegPhoto': {
                ColumnName: 'JPegPhoto',
                Type: ValType.Binary,
                IsReadOnly: false,
            },
            'MaxValidDays': {
                ColumnName: 'MaxValidDays',
                Type: ValType.Int,
                IsReadOnly: false,
            },
            'ProductURL': {
                ColumnName: 'ProductURL',
                Type: ValType.Text,
                IsReadOnly: false,
            },
            'SortOrder': {
                ColumnName: 'SortOrder',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AccProductGroup': {
                ColumnName: 'UID_AccProductGroup',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_AccProductParamCategory': {
                ColumnName: 'UID_AccProductParamCategory',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_FunctionalArea': {
                ColumnName: 'UID_FunctionalArea',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_OrgAttestator': {
                ColumnName: 'UID_OrgAttestator',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_OrgRuler': {
                ColumnName: 'UID_OrgRuler',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_PWODecisionMethod': {
                ColumnName: 'UID_PWODecisionMethod',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_QERTermsOfUse': {
                ColumnName: 'UID_QERTermsOfUse',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AccProduct', Columns: columns };
    };
    return PortalEntitlementServiceitem;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalEntitlementServiceitem type. */
var PortalEntitlementServiceitemInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementServiceitemInteractive, _super);
    function PortalEntitlementServiceitemInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementServiceitemInteractive;
}(PortalEntitlementServiceitem));
var PortalEntitlementSystemrole = /** @class */ (function (_super) {
    __extends(PortalEntitlementSystemrole, _super);
    function PortalEntitlementSystemrole() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalEntitlementSystemrole.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ESet', Columns: columns };
    };
    return PortalEntitlementSystemrole;
}(TypedEntity));
/** @deprecated Use the PortalEntitlementSystemrole type. */
var PortalEntitlementSystemroleInteractive = /** @class */ (function (_super) {
    __extends(PortalEntitlementSystemroleInteractive, _super);
    function PortalEntitlementSystemroleInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalEntitlementSystemroleInteractive;
}(PortalEntitlementSystemrole));
var PortalOwners = /** @class */ (function (_super) {
    __extends(PortalOwners, _super);
    function PortalOwners() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.DefaultEmailAddress = _this.GetEntityValue('DefaultEmailAddress');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalOwners.GetEntitySchema = function () {
        var columns = {
            'DefaultEmailAddress': {
                ColumnName: 'DefaultEmailAddress',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Person', Columns: columns };
    };
    return PortalOwners;
}(TypedEntity));
/** @deprecated Use the PortalOwners type. */
var PortalOwnersInteractive = /** @class */ (function (_super) {
    __extends(PortalOwnersInteractive, _super);
    function PortalOwnersInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalOwnersInteractive;
}(PortalOwners));
var PortalShops = /** @class */ (function (_super) {
    __extends(PortalShops, _super);
    function PortalShops() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalShops.GetEntitySchema = function () {
        var columns = {
            'UID_ITShopOrg': {
                ColumnName: 'UID_ITShopOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ITShopOrg', Columns: columns };
    };
    return PortalShops;
}(TypedEntity));
/** @deprecated Use the PortalShops type. */
var PortalShopsInteractive = /** @class */ (function (_super) {
    __extends(PortalShopsInteractive, _super);
    function PortalShopsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalShopsInteractive;
}(PortalShops));
var PortalApplicationWrapper = /** @class */ (function () {
    function PortalApplicationWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.deleteMethod = function (entity) {
            return _this.client.portal_application_delete(entity.GetColumn('UID_AOBApplication').GetValue());
        };
    }
    /** Returns the runtime schema for this method. */
    PortalApplicationWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/application');
    };
    PortalApplicationWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/application');
            this.builder = new TypedEntityBuilder(PortalApplication, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalApplicationWrapper.prototype.Delete = function (UID_AOBApplication, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_delete(UID_AOBApplication, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationWrapper;
}());
var PortalApplicationIdentitiesWrapper = /** @class */ (function () {
    function PortalApplicationIdentitiesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalApplicationIdentitiesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/application/{uidapplication}/identities');
    };
    PortalApplicationIdentitiesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/application/{uidapplication}/identities');
            this.builder = new TypedEntityBuilder(PortalApplicationIdentities, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationIdentitiesWrapper.prototype.Get = function (uidapplication, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_identities_get(uidapplication, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationIdentitiesWrapper;
}());
var PortalApplicationIdentitiesbyidentityWrapper = /** @class */ (function () {
    function PortalApplicationIdentitiesbyidentityWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalApplicationIdentitiesbyidentityWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/application/{uidapplication}/identities/{uidperson}');
    };
    PortalApplicationIdentitiesbyidentityWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/application/{uidapplication}/identities/{uidperson}');
            this.builder = new TypedEntityBuilder(PortalApplicationIdentitiesbyidentity, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationIdentitiesbyidentityWrapper.prototype.Getbyidentity = function (uidapplication, uidperson, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_identitiesbyidentity_get(uidapplication, uidperson, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationIdentitiesbyidentityWrapper;
}());
var PortalApplicationinshopWrapper = /** @class */ (function () {
    function PortalApplicationinshopWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalApplicationinshopWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/applicationinshop/{uidapplication}');
    };
    PortalApplicationinshopWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/applicationinshop/{uidapplication}');
            this.builder = new TypedEntityBuilder(PortalApplicationinshop, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationinshopWrapper.prototype.Get = function (uidapplication, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_applicationinshop_get(uidapplication, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationinshopWrapper;
}());
var PortalApplicationInteractiveWrapper = /** @class */ (function () {
    function PortalApplicationInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_application_interactive_put(writeData);
        };
        this.deleteMethod = function (entity, deleteData) {
            return _this.client.portal_application_interactive_delete(deleteData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalApplicationInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/application/interactive');
    };
    PortalApplicationInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/application/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalApplication, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalApplicationInteractiveWrapper.prototype.Delete = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_interactive_delete(inputParameterName.InteractiveEntityDeleteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalApplicationInteractiveWrapper.prototype.Get_byid = function (UID_AOBApplication, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_interactive_byid_get(UID_AOBApplication, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationInteractiveWrapper;
}());
var PortalApplicationNewWrapper = /** @class */ (function () {
    function PortalApplicationNewWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_application_new_post(writeData);
            }
        };
    }
    PortalApplicationNewWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalApplicationNewWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/application/new');
    };
    PortalApplicationNewWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/application/new');
            this.builder = new TypedEntityBuilder(PortalApplicationNew, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationNewWrapper.prototype.Post = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_new_post(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationNewWrapper;
}());
var PortalApplicationSqlwizardCandidatesWrapper = /** @class */ (function () {
    function PortalApplicationSqlwizardCandidatesWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalApplicationSqlwizardCandidatesWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/application/sqlwizard/candidates/{table}');
    };
    PortalApplicationSqlwizardCandidatesWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/application/sqlwizard/candidates/{table}');
            this.builder = new TypedEntityBuilder(PortalApplicationSqlwizardCandidates, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationSqlwizardCandidatesWrapper.prototype.Get = function (table, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_application_sqlwizard_candidates_get(table, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationSqlwizardCandidatesWrapper;
}());
var PortalApplicationusesaccountWrapper = /** @class */ (function () {
    function PortalApplicationusesaccountWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.deleteMethod = function (entity) {
            return _this.client.portal_applicationusesaccount_delete(entity.GetColumn('UID_AOBApplication').GetValue(), entity.GetColumn('UID_AOBAppUsesAccount').GetValue());
        };
    }
    /** Returns the runtime schema for this method. */
    PortalApplicationusesaccountWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/applicationusesaccount/{UID_AOBApplication}');
    };
    PortalApplicationusesaccountWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/applicationusesaccount/{UID_AOBApplication}');
            this.builder = new TypedEntityBuilder(PortalApplicationusesaccount, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationusesaccountWrapper.prototype.Get = function (UID_AOBApplication, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_applicationusesaccount_get(UID_AOBApplication, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalApplicationusesaccountWrapper.prototype.Delete = function (UID_AOBApplication, UID_AOBAppUsesAccount, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_applicationusesaccount_delete(UID_AOBApplication, UID_AOBAppUsesAccount, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationusesaccountWrapper;
}());
var PortalApplicationusesaccountNewWrapper = /** @class */ (function () {
    function PortalApplicationusesaccountNewWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_applicationusesaccount_new_post(writeData);
            }
        };
    }
    PortalApplicationusesaccountNewWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalApplicationusesaccountNewWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/applicationusesaccount/new');
    };
    PortalApplicationusesaccountNewWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/applicationusesaccount/new');
            this.builder = new TypedEntityBuilder(PortalApplicationusesaccountNew, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalApplicationusesaccountNewWrapper.prototype.Post = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_applicationusesaccount_new_post(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalApplicationusesaccountNewWrapper;
}());
var PortalCandidatesAccproductparamcategoryWrapper = /** @class */ (function () {
    function PortalCandidatesAccproductparamcategoryWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesAccproductparamcategoryWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/AccProductParamCategory');
    };
    PortalCandidatesAccproductparamcategoryWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/AccProductParamCategory');
            this.builder = new TypedEntityBuilder(PortalCandidatesAccproductparamcategory, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesAccproductparamcategoryWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_AccProductParamCategory_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesAccproductparamcategoryWrapper;
}());
var PortalCandidatesAeroleWrapper = /** @class */ (function () {
    function PortalCandidatesAeroleWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesAeroleWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/AERole');
    };
    PortalCandidatesAeroleWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/AERole');
            this.builder = new TypedEntityBuilder(PortalCandidatesAerole, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesAeroleWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_AERole_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesAeroleWrapper;
}());
var PortalCandidatesAobapplicationWrapper = /** @class */ (function () {
    function PortalCandidatesAobapplicationWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesAobapplicationWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/AOBApplication');
    };
    PortalCandidatesAobapplicationWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/AOBApplication');
            this.builder = new TypedEntityBuilder(PortalCandidatesAobapplication, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesAobapplicationWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_AOBApplication_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesAobapplicationWrapper;
}());
var PortalCandidatesApplicationWrapper = /** @class */ (function () {
    function PortalCandidatesApplicationWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesApplicationWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/Application');
    };
    PortalCandidatesApplicationWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/Application');
            this.builder = new TypedEntityBuilder(PortalCandidatesApplication, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesApplicationWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_Application_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesApplicationWrapper;
}());
var PortalCandidatesEsetWrapper = /** @class */ (function () {
    function PortalCandidatesEsetWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesEsetWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/ESet');
    };
    PortalCandidatesEsetWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/ESet');
            this.builder = new TypedEntityBuilder(PortalCandidatesEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesEsetWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_ESet_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesEsetWrapper;
}());
var PortalCandidatesFunctionalareaWrapper = /** @class */ (function () {
    function PortalCandidatesFunctionalareaWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesFunctionalareaWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/FunctionalArea');
    };
    PortalCandidatesFunctionalareaWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/FunctionalArea');
            this.builder = new TypedEntityBuilder(PortalCandidatesFunctionalarea, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesFunctionalareaWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_FunctionalArea_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesFunctionalareaWrapper;
}());
var PortalCandidatesOrgWrapper = /** @class */ (function () {
    function PortalCandidatesOrgWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesOrgWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/Org');
    };
    PortalCandidatesOrgWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/Org');
            this.builder = new TypedEntityBuilder(PortalCandidatesOrg, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesOrgWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_Org_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesOrgWrapper;
}());
var PortalCandidatesPersonWrapper = /** @class */ (function () {
    function PortalCandidatesPersonWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesPersonWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/Person');
    };
    PortalCandidatesPersonWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/Person');
            this.builder = new TypedEntityBuilder(PortalCandidatesPerson, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesPersonWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_Person_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesPersonWrapper;
}());
var PortalCandidatesQerassignWrapper = /** @class */ (function () {
    function PortalCandidatesQerassignWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesQerassignWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/QERAssign');
    };
    PortalCandidatesQerassignWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/QERAssign');
            this.builder = new TypedEntityBuilder(PortalCandidatesQerassign, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesQerassignWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_QERAssign_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesQerassignWrapper;
}());
var PortalCandidatesQerresourceWrapper = /** @class */ (function () {
    function PortalCandidatesQerresourceWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesQerresourceWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/QERResource');
    };
    PortalCandidatesQerresourceWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/QERResource');
            this.builder = new TypedEntityBuilder(PortalCandidatesQerresource, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesQerresourceWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_QERResource_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesQerresourceWrapper;
}());
var PortalCandidatesQerreuseWrapper = /** @class */ (function () {
    function PortalCandidatesQerreuseWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesQerreuseWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/QERReuse');
    };
    PortalCandidatesQerreuseWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/QERReuse');
            this.builder = new TypedEntityBuilder(PortalCandidatesQerreuse, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesQerreuseWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_QERReuse_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesQerreuseWrapper;
}());
var PortalCandidatesQerreuseusWrapper = /** @class */ (function () {
    function PortalCandidatesQerreuseusWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesQerreuseusWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/QERReuseUS');
    };
    PortalCandidatesQerreuseusWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/QERReuseUS');
            this.builder = new TypedEntityBuilder(PortalCandidatesQerreuseus, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesQerreuseusWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_QERReuseUS_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesQerreuseusWrapper;
}());
var PortalCandidatesQertermsofuseWrapper = /** @class */ (function () {
    function PortalCandidatesQertermsofuseWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesQertermsofuseWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/QERTermsOfUse');
    };
    PortalCandidatesQertermsofuseWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/QERTermsOfUse');
            this.builder = new TypedEntityBuilder(PortalCandidatesQertermsofuse, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesQertermsofuseWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_QERTermsOfUse_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesQertermsofuseWrapper;
}());
var PortalCandidatesRpsreportWrapper = /** @class */ (function () {
    function PortalCandidatesRpsreportWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesRpsreportWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/RPSReport');
    };
    PortalCandidatesRpsreportWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/RPSReport');
            this.builder = new TypedEntityBuilder(PortalCandidatesRpsreport, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesRpsreportWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_RPSReport_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesRpsreportWrapper;
}());
var PortalCandidatesTsbaccountdefWrapper = /** @class */ (function () {
    function PortalCandidatesTsbaccountdefWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesTsbaccountdefWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/TSBAccountDef');
    };
    PortalCandidatesTsbaccountdefWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/TSBAccountDef');
            this.builder = new TypedEntityBuilder(PortalCandidatesTsbaccountdef, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesTsbaccountdefWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_TSBAccountDef_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesTsbaccountdefWrapper;
}());
var PortalCandidatesUnsaccountbWrapper = /** @class */ (function () {
    function PortalCandidatesUnsaccountbWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesUnsaccountbWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/UNSAccountB');
    };
    PortalCandidatesUnsaccountbWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/UNSAccountB');
            this.builder = new TypedEntityBuilder(PortalCandidatesUnsaccountb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesUnsaccountbWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_UNSAccountB_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesUnsaccountbWrapper;
}());
var PortalCandidatesUnsgroupWrapper = /** @class */ (function () {
    function PortalCandidatesUnsgroupWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesUnsgroupWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/UNSGroup');
    };
    PortalCandidatesUnsgroupWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/UNSGroup');
            this.builder = new TypedEntityBuilder(PortalCandidatesUnsgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesUnsgroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_UNSGroup_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesUnsgroupWrapper;
}());
var PortalCandidatesUnsrootWrapper = /** @class */ (function () {
    function PortalCandidatesUnsrootWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalCandidatesUnsrootWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/candidates/UNSRoot');
    };
    PortalCandidatesUnsrootWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/candidates/UNSRoot');
            this.builder = new TypedEntityBuilder(PortalCandidatesUnsroot, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalCandidatesUnsrootWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_candidates_UNSRoot_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalCandidatesUnsrootWrapper;
}());
var PortalEntitlementWrapper = /** @class */ (function () {
    function PortalEntitlementWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.deleteMethod = function (entity) {
            return _this.client.portal_entitlement_delete(entity.GetColumn('UID_AOBEntitlement').GetValue());
        };
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlement');
    };
    PortalEntitlementWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlement');
            this.builder = new TypedEntityBuilder(PortalEntitlement, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalEntitlementWrapper.prototype.Delete = function (UID_AOBEntitlement, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_delete(UID_AOBEntitlement, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementWrapper;
}());
var PortalEntitlementcandidatesEsetWrapper = /** @class */ (function () {
    function PortalEntitlementcandidatesEsetWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementcandidatesEsetWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlementcandidates/ESet');
    };
    PortalEntitlementcandidatesEsetWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlementcandidates/ESet');
            this.builder = new TypedEntityBuilder(PortalEntitlementcandidatesEset, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementcandidatesEsetWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlementcandidates_ESet_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementcandidatesEsetWrapper;
}());
var PortalEntitlementcandidatesQerresourceWrapper = /** @class */ (function () {
    function PortalEntitlementcandidatesQerresourceWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementcandidatesQerresourceWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlementcandidates/QERResource');
    };
    PortalEntitlementcandidatesQerresourceWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlementcandidates/QERResource');
            this.builder = new TypedEntityBuilder(PortalEntitlementcandidatesQerresource, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementcandidatesQerresourceWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlementcandidates_QERResource_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementcandidatesQerresourceWrapper;
}());
var PortalEntitlementcandidatesRpsreportWrapper = /** @class */ (function () {
    function PortalEntitlementcandidatesRpsreportWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementcandidatesRpsreportWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlementcandidates/RPSReport');
    };
    PortalEntitlementcandidatesRpsreportWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlementcandidates/RPSReport');
            this.builder = new TypedEntityBuilder(PortalEntitlementcandidatesRpsreport, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementcandidatesRpsreportWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlementcandidates_RPSReport_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementcandidatesRpsreportWrapper;
}());
var PortalEntitlementcandidatesTsbaccountdefWrapper = /** @class */ (function () {
    function PortalEntitlementcandidatesTsbaccountdefWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementcandidatesTsbaccountdefWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlementcandidates/TSBAccountDef');
    };
    PortalEntitlementcandidatesTsbaccountdefWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlementcandidates/TSBAccountDef');
            this.builder = new TypedEntityBuilder(PortalEntitlementcandidatesTsbaccountdef, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementcandidatesTsbaccountdefWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlementcandidates_TSBAccountDef_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementcandidatesTsbaccountdefWrapper;
}());
var PortalEntitlementcandidatesUnsgroupWrapper = /** @class */ (function () {
    function PortalEntitlementcandidatesUnsgroupWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementcandidatesUnsgroupWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlementcandidates/UNSGroup');
    };
    PortalEntitlementcandidatesUnsgroupWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlementcandidates/UNSGroup');
            this.builder = new TypedEntityBuilder(PortalEntitlementcandidatesUnsgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementcandidatesUnsgroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlementcandidates_UNSGroup_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementcandidatesUnsgroupWrapper;
}());
var PortalEntitlementInteractiveWrapper = /** @class */ (function () {
    function PortalEntitlementInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_entitlement_interactive_put(writeData);
        };
        this.deleteMethod = function (entity, deleteData) {
            return _this.client.portal_entitlement_interactive_delete(deleteData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlement/interactive');
    };
    PortalEntitlementInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlement/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalEntitlement, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalEntitlementInteractiveWrapper.prototype.Delete = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_interactive_delete(inputParameterName.InteractiveEntityDeleteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalEntitlementInteractiveWrapper.prototype.Get_byid = function (UID_AOBEntitlement, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_interactive_byid_get(UID_AOBEntitlement, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalEntitlementInteractiveWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_interactive_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementInteractiveWrapper;
}());
var PortalEntitlementServiceitemWrapper = /** @class */ (function () {
    function PortalEntitlementServiceitemWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_entitlement_serviceitem_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementServiceitemWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlement/serviceitem');
    };
    PortalEntitlementServiceitemWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlement/serviceitem');
            this.builder = new TypedEntityBuilder(PortalEntitlementServiceitem, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementServiceitemWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_serviceitem_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalEntitlementServiceitemWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_serviceitem_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementServiceitemWrapper;
}());
var PortalEntitlementSystemroleWrapper = /** @class */ (function () {
    function PortalEntitlementSystemroleWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalEntitlementSystemroleWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/entitlement/{uidapplication}/systemrole');
    };
    PortalEntitlementSystemroleWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/entitlement/{uidapplication}/systemrole');
            this.builder = new TypedEntityBuilder(PortalEntitlementSystemrole, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalEntitlementSystemroleWrapper.prototype.Get = function (uidapplication, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_entitlement_systemrole_get(uidapplication, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalEntitlementSystemroleWrapper;
}());
var PortalOwnersWrapper = /** @class */ (function () {
    function PortalOwnersWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalOwnersWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/owners/{tablename}/{uid}');
    };
    PortalOwnersWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/owners/{tablename}/{uid}');
            this.builder = new TypedEntityBuilder(PortalOwners, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalOwnersWrapper.prototype.Get = function (tablename, uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_owners_get(tablename, uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalOwnersWrapper;
}());
var PortalShopsWrapper = /** @class */ (function () {
    function PortalShopsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalShopsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/shops');
    };
    PortalShopsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/shops');
            this.builder = new TypedEntityBuilder(PortalShops, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalShopsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shops_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalShopsWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_application_get = function (filterkpi, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/application',
            parameters: [
                {
                    name: 'filterkpi',
                    value: filterkpi,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_delete = function (UID_AOBApplication) {
        return {
            path: '/portal/application/{UID_AOBApplication}',
            parameters: [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_map_post = function (UID_AOBApplication) {
        return {
            path: '/portal/application/{UID_AOBApplication}/map',
            parameters: [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_identities_get = function (uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/application/{uidapplication}/identities',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_identitiesbyidentity_get = function (uidapplication, uidperson, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/application/{uidapplication}/identities/{uidperson}',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidperson',
                    value: uidperson,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_kpi_get = function (uidapplication) {
        return {
            path: '/portal/application/{uidapplication}/kpi',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_group_get = function (by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/application/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/application/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_delete = function (inputParameterName) {
        return {
            path: '/portal/application/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_entitlementstoadd_get = function (entityid, keys, state) {
        return {
            path: '/portal/application/interactive/{entityid}/entitlementstoadd',
            parameters: [
                {
                    name: 'entityid',
                    value: entityid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'keys',
                    value: keys,
                    in: 'query'
                },
                {
                    name: 'state',
                    value: state,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_byid_get = function (UID_AOBApplication) {
        return {
            path: '/portal/application/interactive/{UID_AOBApplication}',
            parameters: [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleApprover_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/application/interactive/UID_AERoleApprover/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/application/interactive/UID_AERoleApprover/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleOwner_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/application/interactive/UID_AERoleOwner/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/application/interactive/UID_AERoleOwner/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_new_post = function (inputParameterName) {
        return {
            path: '/portal/application/new',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_new_UID_AccProductGroup_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/application/new/UID_AccProductGroup/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_new_UID_AccProductGroup_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/application/new/UID_AccProductGroup/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleApprover_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/application/new/UID_AERoleApprover/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleApprover_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/application/new/UID_AERoleApprover/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleOwner_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/application/new/UID_AERoleOwner/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleOwner_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/application/new/UID_AERoleOwner/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_sqlwizard_candidates_get = function (table, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/application/sqlwizard/candidates/{table}',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_application_sqlwizard_tables_columns_get = function (table) {
        return {
            path: '/portal/application/sqlwizard/tables/{table}/columns',
            parameters: [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationimage_get = function (uidapplication) {
        return {
            path: '/portal/applicationimage/{uidapplication}',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'blob'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationimage_post = function (uidapplication, inputParameterName) {
        return {
            path: '/portal/applicationimage/{uidapplication}',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationinshop_get = function (uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/applicationinshop/{uidapplication}',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationinshop_put = function (uidapplication, uidshop, inputParameterName) {
        return {
            path: '/portal/applicationinshop/{uidapplication}/{uidshop}',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidshop',
                    value: uidshop,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationinshop_delete = function (uidapplication, uidshop, inputParameterName) {
        return {
            path: '/portal/applicationinshop/{uidapplication}/{uidshop}',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidshop',
                    value: uidshop,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationusesaccount_get = function (UID_AOBApplication, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/applicationusesaccount/{UID_AOBApplication}',
            parameters: [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationusesaccount_delete = function (UID_AOBApplication, UID_AOBAppUsesAccount) {
        return {
            path: '/portal/applicationusesaccount/{UID_AOBApplication}/{UID_AOBAppUsesAccount}',
            parameters: [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AOBAppUsesAccount',
                    value: UID_AOBAppUsesAccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_applicationusesaccount_new_post = function (inputParameterName) {
        return {
            path: '/portal/applicationusesaccount/new',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/AccProductParamCategory',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/AccProductParamCategory/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_AERole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/candidates/AERole',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_AERole_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/AERole/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_AOBApplication_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/AOBApplication',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_AOBApplication_datamodel_get = function (filter) {
        return {
            path: '/portal/candidates/AOBApplication/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_AOBApplication_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/AOBApplication/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Application_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/Application',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Application_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/Application/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_ESet_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/ESet',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_ESet_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/ESet/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_FunctionalArea_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/candidates/FunctionalArea',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_FunctionalArea_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/FunctionalArea/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/candidates/Org',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Org_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/Org/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Person_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/Person',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_Person_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/Person/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERAssign_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/QERAssign',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERAssign_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/QERAssign/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERResource_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/QERResource',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERResource_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/QERResource/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERReuse_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/QERReuse',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERReuse_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/QERReuse/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERReuseUS_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/QERReuseUS',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERReuseUS_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/QERReuseUS/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/QERTermsOfUse',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/QERTermsOfUse/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_RPSReport_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/RPSReport',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_RPSReport_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/RPSReport/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_TSBAccountDef_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/TSBAccountDef',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_TSBAccountDef_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/TSBAccountDef/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_UNSAccountB_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/UNSAccountB',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_UNSAccountB_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/UNSAccountB/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_UNSGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/UNSGroup',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_UNSGroup_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/UNSGroup/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_UNSRoot_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/candidates/UNSRoot',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_candidates_UNSRoot_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/candidates/UNSRoot/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlement',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_delete = function (UID_AOBEntitlement) {
        return {
            path: '/portal/entitlement/{UID_AOBEntitlement}',
            parameters: [
                {
                    name: 'UID_AOBEntitlement',
                    value: UID_AOBEntitlement,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_systemrole_get = function (uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlement/{uidapplication}/systemrole',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_group_get = function (by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/entitlement/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_interactive_get = function () {
        return {
            path: '/portal/entitlement/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/entitlement/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_interactive_delete = function (inputParameterName) {
        return {
            path: '/portal/entitlement/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_interactive_byid_get = function (UID_AOBEntitlement) {
        return {
            path: '/portal/entitlement/interactive/{UID_AOBEntitlement}',
            parameters: [
                {
                    name: 'UID_AOBEntitlement',
                    value: UID_AOBEntitlement,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/entitlement/interactive/UID_AERoleOwner/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/entitlement/interactive/UID_AERoleOwner/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_get = function (uid_aobentitlement, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlement/serviceitem',
            parameters: [
                {
                    name: 'uid_aobentitlement',
                    value: uid_aobentitlement,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_put = function (inputParameterName) {
        return {
            path: '/portal/entitlement/serviceitem',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/entitlement/serviceitem/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_datamodel_get = function (filter) {
        return {
            path: '/portal/entitlement/serviceitem/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName) {
        return {
            path: '/portal/entitlement/serviceitem/UID_AccProductGroup/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/entitlement/serviceitem/UID_AccProductGroup/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgAttestator/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgAttestator/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgRuler/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgRuler/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlement/serviceitem/UID_PWODecisionMethod/candidates',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName) {
        return {
            path: '/portal/entitlement/serviceitem/UID_PWODecisionMethod/candidates/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlement_systemrole_post = function (inputParameterName) {
        return {
            path: '/portal/entitlement/systemrole',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_ESet_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlementcandidates/ESet',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_ESet_datamodel_get = function (filter) {
        return {
            path: '/portal/entitlementcandidates/ESet/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_ESet_group_get = function (by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/entitlementcandidates/ESet/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_QERResource_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlementcandidates/QERResource',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_QERResource_datamodel_get = function (filter) {
        return {
            path: '/portal/entitlementcandidates/QERResource/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_QERResource_group_get = function (by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/entitlementcandidates/QERResource/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_RPSReport_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlementcandidates/RPSReport',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_RPSReport_datamodel_get = function (filter) {
        return {
            path: '/portal/entitlementcandidates/RPSReport/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_RPSReport_group_get = function (by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/entitlementcandidates/RPSReport/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_TSBAccountDef_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/entitlementcandidates/TSBAccountDef',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_TSBAccountDef_datamodel_get = function (filter) {
        return {
            path: '/portal/entitlementcandidates/TSBAccountDef/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_TSBAccountDef_group_get = function (by, def, filter, StartIndex, PageSize, withcount) {
        return {
            path: '/portal/entitlementcandidates/TSBAccountDef/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, namespace) {
        return {
            path: '/portal/entitlementcandidates/UNSGroup',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'namespace',
                    value: namespace,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_datamodel_get = function (filter) {
        return {
            path: '/portal/entitlementcandidates/UNSGroup/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_filtertree_get = function (filter, parentkey) {
        return {
            path: '/portal/entitlementcandidates/UNSGroup/filtertree',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_group_get = function (by, def, filter, StartIndex, PageSize, withcount, namespace) {
        return {
            path: '/portal/entitlementcandidates/UNSGroup/group',
            parameters: [
                {
                    name: 'by',
                    value: by,
                    in: 'query'
                },
                {
                    name: 'def',
                    value: def,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'withcount',
                    value: withcount,
                    in: 'query'
                },
                {
                    name: 'namespace',
                    value: namespace,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementimage_get = function (uidentitlement) {
        return {
            path: '/portal/entitlementimage/{uidentitlement}',
            parameters: [
                {
                    name: 'uidentitlement',
                    value: uidentitlement,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'blob'
        };
    };
    ApiClientMethodFactory.prototype.portal_entitlementimage_post = function (uidentitlement, inputParameterName) {
        return {
            path: '/portal/entitlementimage/{uidentitlement}',
            parameters: [
                {
                    name: 'uidentitlement',
                    value: uidentitlement,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_kpi_get = function () {
        return {
            path: '/portal/kpi',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_owners_get = function (tablename, uid, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/owners/{tablename}/{uid}',
            parameters: [
                {
                    name: 'tablename',
                    value: tablename,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_publish_application_post = function (uidapplication, date, inputParameterName) {
        return {
            path: '/portal/publish/application/{uidapplication}',
            parameters: [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'date',
                    value: date,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shops_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
        return {
            path: '/portal/shops',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'ParentKey',
                    value: ParentKey,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_application_get = function (filterkpi, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_get(filterkpi, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_application_delete = function (UID_AOBApplication, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_delete(UID_AOBApplication), requestOptions);
    };
    /** Starts the entitlement mapping process for the specified application. */
    Client.prototype.portal_application_map_post = function (UID_AOBApplication, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_map_post(UID_AOBApplication), requestOptions);
    };
    /** Returns all identities having access to at least one entitlement of the application. */
    Client.prototype.portal_application_identities_get = function (uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_identities_get(uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns all entitlements that the specified identity has access to. */
    Client.prototype.portal_application_identitiesbyidentity_get = function (uidapplication, uidperson, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_identitiesbyidentity_get(uidapplication, uidperson, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns application-specific KPI information. */
    Client.prototype.portal_application_kpi_get = function (uidapplication, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_kpi_get(uidapplication), requestOptions);
    };
    Client.prototype.portal_application_group_get = function (by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_group_get(by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    Client.prototype.portal_application_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_application_interactive_delete = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_delete(inputParameterName), requestOptions);
    };
    Client.prototype.portal_application_interactive_entitlementstoadd_get = function (entityid, keys, state, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_entitlementstoadd_get(entityid, keys, state), requestOptions);
    };
    Client.prototype.portal_application_interactive_byid_get = function (UID_AOBApplication, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_byid_get(UID_AOBApplication), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    Client.prototype.portal_application_interactive_UID_AERoleApprover_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleApprover_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the application/interactive/UID_AERoleApprover/candidates endpoint. */
    Client.prototype.portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    Client.prototype.portal_application_interactive_UID_AERoleOwner_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleOwner_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the application/interactive/UID_AERoleOwner/candidates endpoint. */
    Client.prototype.portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_application_new_post = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_post(inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    Client.prototype.portal_application_new_UID_AccProductGroup_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AccProductGroup_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the application/new/UID_AccProductGroup/candidates endpoint. */
    Client.prototype.portal_application_new_UID_AccProductGroup_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AccProductGroup_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    Client.prototype.portal_application_new_UID_AERoleApprover_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleApprover_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the application/new/UID_AERoleApprover/candidates endpoint. */
    Client.prototype.portal_application_new_UID_AERoleApprover_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleApprover_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    Client.prototype.portal_application_new_UID_AERoleOwner_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleOwner_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the application/new/UID_AERoleOwner/candidates endpoint. */
    Client.prototype.portal_application_new_UID_AERoleOwner_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleOwner_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned as a filter parameter. */
    Client.prototype.portal_application_sqlwizard_candidates_get = function (table, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_sqlwizard_candidates_get(table, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns the filterable properties for the specified table. */
    Client.prototype.portal_application_sqlwizard_tables_columns_get = function (table, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_sqlwizard_tables_columns_get(table), requestOptions);
    };
    Client.prototype.portal_applicationimage_get = function (uidapplication, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationimage_get(uidapplication), requestOptions);
    };
    Client.prototype.portal_applicationimage_post = function (uidapplication, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationimage_post(uidapplication, inputParameterName), requestOptions);
    };
    Client.prototype.portal_applicationinshop_get = function (uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationinshop_get(uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Assigns an application to a shop. */
    Client.prototype.portal_applicationinshop_put = function (uidapplication, uidshop, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationinshop_put(uidapplication, uidshop, inputParameterName), requestOptions);
    };
    /** Removes an application from a shop. */
    Client.prototype.portal_applicationinshop_delete = function (uidapplication, uidshop, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationinshop_delete(uidapplication, uidshop, inputParameterName), requestOptions);
    };
    /** Returns the list of accounts used by the specified application. */
    Client.prototype.portal_applicationusesaccount_get = function (UID_AOBApplication, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationusesaccount_get(UID_AOBApplication, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns the list of accounts used by the specified application. */
    Client.prototype.portal_applicationusesaccount_delete = function (UID_AOBApplication, UID_AOBAppUsesAccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationusesaccount_delete(UID_AOBApplication, UID_AOBAppUsesAccount), requestOptions);
    };
    /** Defines that an application uses a specific account. */
    Client.prototype.portal_applicationusesaccount_new_post = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationusesaccount_new_post(inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    Client.prototype.portal_candidates_AccProductParamCategory_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    Client.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table AERole. */
    Client.prototype.portal_candidates_AERole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the candidates/AERole endpoint. */
    Client.prototype.portal_candidates_AERole_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table AOBApplication. */
    Client.prototype.portal_candidates_AOBApplication_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AOBApplication_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the candidates/AOBApplication endpoint. */
    Client.prototype.portal_candidates_AOBApplication_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AOBApplication_datamodel_get(filter), requestOptions);
    };
    /** Returns filter tree information for the candidates/AOBApplication endpoint. */
    Client.prototype.portal_candidates_AOBApplication_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AOBApplication_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table Application. */
    Client.prototype.portal_candidates_Application_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Application_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/Application endpoint. */
    Client.prototype.portal_candidates_Application_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Application_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table ESet. */
    Client.prototype.portal_candidates_ESet_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_ESet_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/ESet endpoint. */
    Client.prototype.portal_candidates_ESet_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_ESet_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table FunctionalArea. */
    Client.prototype.portal_candidates_FunctionalArea_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_FunctionalArea_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the candidates/FunctionalArea endpoint. */
    Client.prototype.portal_candidates_FunctionalArea_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_FunctionalArea_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table Org. */
    Client.prototype.portal_candidates_Org_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the candidates/Org endpoint. */
    Client.prototype.portal_candidates_Org_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table Person. */
    Client.prototype.portal_candidates_Person_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/Person endpoint. */
    Client.prototype.portal_candidates_Person_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERAssign. */
    Client.prototype.portal_candidates_QERAssign_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERAssign_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERAssign endpoint. */
    Client.prototype.portal_candidates_QERAssign_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERAssign_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERResource. */
    Client.prototype.portal_candidates_QERResource_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERResource_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERResource endpoint. */
    Client.prototype.portal_candidates_QERResource_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERResource_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERReuse. */
    Client.prototype.portal_candidates_QERReuse_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuse_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERReuse endpoint. */
    Client.prototype.portal_candidates_QERReuse_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuse_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERReuseUS. */
    Client.prototype.portal_candidates_QERReuseUS_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuseUS_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERReuseUS endpoint. */
    Client.prototype.portal_candidates_QERReuseUS_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuseUS_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERTermsOfUse. */
    Client.prototype.portal_candidates_QERTermsOfUse_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
    Client.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table RPSReport. */
    Client.prototype.portal_candidates_RPSReport_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_RPSReport_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/RPSReport endpoint. */
    Client.prototype.portal_candidates_RPSReport_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_RPSReport_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table TSBAccountDef. */
    Client.prototype.portal_candidates_TSBAccountDef_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_TSBAccountDef_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/TSBAccountDef endpoint. */
    Client.prototype.portal_candidates_TSBAccountDef_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_TSBAccountDef_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table UNSAccountB. */
    Client.prototype.portal_candidates_UNSAccountB_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSAccountB_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/UNSAccountB endpoint. */
    Client.prototype.portal_candidates_UNSAccountB_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSAccountB_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table UNSGroup. */
    Client.prototype.portal_candidates_UNSGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSGroup_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/UNSGroup endpoint. */
    Client.prototype.portal_candidates_UNSGroup_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSGroup_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of candidate objects from the table UNSRoot. */
    Client.prototype.portal_candidates_UNSRoot_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSRoot_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the candidates/UNSRoot endpoint. */
    Client.prototype.portal_candidates_UNSRoot_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSRoot_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_entitlement_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_entitlement_delete = function (UID_AOBEntitlement, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_delete(UID_AOBEntitlement), requestOptions);
    };
    Client.prototype.portal_entitlement_systemrole_get = function (uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_systemrole_get(uidapplication, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_entitlement_group_get = function (by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_group_get(by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    Client.prototype.portal_entitlement_interactive_get = function (requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_get(), requestOptions);
    };
    Client.prototype.portal_entitlement_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_entitlement_interactive_delete = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_delete(inputParameterName), requestOptions);
    };
    Client.prototype.portal_entitlement_interactive_byid_get = function (UID_AOBEntitlement, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_byid_get(UID_AOBEntitlement), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    Client.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_UID_AERoleOwner_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the entitlement/interactive/UID_AERoleOwner/candidates endpoint. */
    Client.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_entitlement_serviceitem_get = function (uid_aobentitlement, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_get(uid_aobentitlement, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_entitlement_serviceitem_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_entitlement_serviceitem_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the entitlement/serviceitem endpoint. */
    Client.prototype.portal_entitlement_serviceitem_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_datamodel_get(filter), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    Client.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, inputParameterName), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_AccProductGroup/candidates endpoint. */
    Client.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    Client.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgAttestator/candidates endpoint. */
    Client.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    Client.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgRuler/candidates endpoint. */
    Client.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    Client.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    Client.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
    };
    /** Adds entitlements to a new or existing system role, and adds the system role to the application. */
    Client.prototype.portal_entitlement_systemrole_post = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_systemrole_post(inputParameterName), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_ESet_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_ESet_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/ESet endpoint. */
    Client.prototype.portal_entitlementcandidates_ESet_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_ESet_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_ESet_group_get = function (by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_ESet_group_get(by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_QERResource_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_QERResource_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/QERResource endpoint. */
    Client.prototype.portal_entitlementcandidates_QERResource_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_QERResource_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_QERResource_group_get = function (by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_QERResource_group_get(by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_RPSReport_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_RPSReport_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/RPSReport endpoint. */
    Client.prototype.portal_entitlementcandidates_RPSReport_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_RPSReport_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_RPSReport_group_get = function (by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_RPSReport_group_get(by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_TSBAccountDef_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_TSBAccountDef_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/TSBAccountDef endpoint. */
    Client.prototype.portal_entitlementcandidates_TSBAccountDef_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_TSBAccountDef_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_TSBAccountDef_group_get = function (by, def, filter, StartIndex, PageSize, withcount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_TSBAccountDef_group_get(by, def, filter, StartIndex, PageSize, withcount), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_UNSGroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, namespace, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, namespace), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/UNSGroup endpoint. */
    Client.prototype.portal_entitlementcandidates_UNSGroup_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_datamodel_get(filter), requestOptions);
    };
    /** Returns filter tree information for the entitlementcandidates/UNSGroup endpoint. */
    Client.prototype.portal_entitlementcandidates_UNSGroup_filtertree_get = function (filter, parentkey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_filtertree_get(filter, parentkey), requestOptions);
    };
    Client.prototype.portal_entitlementcandidates_UNSGroup_group_get = function (by, def, filter, StartIndex, PageSize, withcount, namespace, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_group_get(by, def, filter, StartIndex, PageSize, withcount, namespace), requestOptions);
    };
    Client.prototype.portal_entitlementimage_get = function (uidentitlement, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementimage_get(uidentitlement), requestOptions);
    };
    Client.prototype.portal_entitlementimage_post = function (uidentitlement, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementimage_post(uidentitlement, inputParameterName), requestOptions);
    };
    /** Returns global KPI information for application governance. */
    Client.prototype.portal_kpi_get = function (requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_kpi_get(), requestOptions);
    };
    /** Returns owner information for the specified entitlement */
    Client.prototype.portal_owners_get = function (tablename, uid, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_owners_get(tablename, uid, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_publish_application_post = function (uidapplication, date, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_publish_application_post(uidapplication, date, inputParameterName), requestOptions);
    };
    Client.prototype.portal_shops_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shops_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_application_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_delete = function (/** Application */ UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/{UID_AOBApplication}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_map_post = function (/** Unique application identifier */ UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/{UID_AOBApplication}/map',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_identities_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/{uidapplication}/identities',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_identitiesbyidentity_get = function (/** Unique application identifier */ uidapplication, /** Unique identity identifier */ uidperson, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/{uidapplication}/identities/{uidperson}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidperson',
                    value: uidperson,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_kpi_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/{uidapplication}/kpi',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_entitlementstoadd_get = function (entityid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive/{entityid}/entitlementstoadd',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'entityid',
                    value: entityid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_byid_get = function (/** Primary key value UID_AOBApplication */ UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive/{UID_AOBApplication}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleApprover_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive/UID_AERoleApprover/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive/UID_AERoleApprover/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleOwner_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive/UID_AERoleOwner/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/interactive/UID_AERoleOwner/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_new_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/new',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_new_UID_AccProductGroup_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/new/UID_AccProductGroup/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_new_UID_AccProductGroup_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/new/UID_AccProductGroup/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleApprover_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/new/UID_AERoleApprover/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleApprover_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/new/UID_AERoleApprover/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleOwner_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/new/UID_AERoleOwner/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_new_UID_AERoleOwner_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/new/UID_AERoleOwner/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_sqlwizard_candidates_get = function (/** Name of the candidate table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/sqlwizard/candidates/{table}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_application_sqlwizard_tables_columns_get = function (/** Name of the filtered database table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/application/sqlwizard/tables/{table}/columns',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'table',
                    value: table,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationimage_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationimage/{uidapplication}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'blob'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationimage_post = function (/** Unique application identifier */ uidapplication, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationimage/{uidapplication}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationinshop_get = function (uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationinshop/{uidapplication}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationinshop_put = function (uidapplication, uidshop, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationinshop/{uidapplication}/{uidshop}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidshop',
                    value: uidshop,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationinshop_delete = function (uidapplication, uidshop, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationinshop/{uidapplication}/{uidshop}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidshop',
                    value: uidshop,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationusesaccount_get = function (UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationusesaccount/{UID_AOBApplication}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationusesaccount_delete = function (UID_AOBApplication, /** Application: user account assignment */ UID_AOBAppUsesAccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationusesaccount/{UID_AOBApplication}/{UID_AOBAppUsesAccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AOBApplication',
                    value: UID_AOBApplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AOBAppUsesAccount',
                    value: UID_AOBAppUsesAccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_applicationusesaccount_new_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/applicationusesaccount/new',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/AccProductParamCategory',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/AccProductParamCategory/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_AERole_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/AERole',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_AERole_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/AERole/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_AOBApplication_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/AOBApplication',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_AOBApplication_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/AOBApplication/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_AOBApplication_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/AOBApplication/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Application_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Application',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Application_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Application/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_ESet_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/ESet',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_ESet_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/ESet/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_FunctionalArea_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/FunctionalArea',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_FunctionalArea_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/FunctionalArea/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Org_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Org',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Org_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Org/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Person_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Person',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_Person_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/Person/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERAssign_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERAssign',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERAssign_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERAssign/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERResource_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERResource',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERResource_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERResource/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERReuse_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERReuse',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERReuse_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERReuse/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERReuseUS_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERReuseUS',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERReuseUS_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERReuseUS/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERTermsOfUse',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/QERTermsOfUse/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_RPSReport_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/RPSReport',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_RPSReport_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/RPSReport/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_TSBAccountDef_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/TSBAccountDef',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_TSBAccountDef_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/TSBAccountDef/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_UNSAccountB_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/UNSAccountB',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_UNSAccountB_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/UNSAccountB/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_UNSGroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/UNSGroup',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_UNSGroup_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/UNSGroup/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_UNSRoot_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/UNSRoot',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_candidates_UNSRoot_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/candidates/UNSRoot/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_delete = function (/** Entitlement */ UID_AOBEntitlement, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/{UID_AOBEntitlement}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AOBEntitlement',
                    value: UID_AOBEntitlement,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_systemrole_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/{uidapplication}/systemrole',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_interactive_get = function (options, requestOptions) {
        return {
            path: '/portal/entitlement/interactive',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_interactive_byid_get = function (/** Primary key value UID_AOBEntitlement */ UID_AOBEntitlement, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/interactive/{UID_AOBEntitlement}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AOBEntitlement',
                    value: UID_AOBEntitlement,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/interactive/UID_AERoleOwner/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/interactive/UID_AERoleOwner/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_AccProductGroup/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_AccProductGroup/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgAttestator/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgAttestator/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgRuler/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_OrgRuler/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_PWODecisionMethod/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/serviceitem/UID_PWODecisionMethod/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlement_systemrole_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlement/systemrole',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_ESet_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/ESet',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_ESet_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/ESet/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_ESet_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/ESet/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_QERResource_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/QERResource',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_QERResource_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/QERResource/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_QERResource_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/QERResource/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_RPSReport_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/RPSReport',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_RPSReport_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/RPSReport/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_RPSReport_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/RPSReport/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_TSBAccountDef_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/TSBAccountDef',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_TSBAccountDef_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/TSBAccountDef/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_TSBAccountDef_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/TSBAccountDef/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/UNSGroup',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/UNSGroup/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_filtertree_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/UNSGroup/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementcandidates_UNSGroup_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementcandidates/UNSGroup/group',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementimage_get = function (/** Unique entitlement identifier */ uidentitlement, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementimage/{uidentitlement}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidentitlement',
                    value: uidentitlement,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'blob'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_entitlementimage_post = function (/** Unique entitlement identifier */ uidentitlement, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/entitlementimage/{uidentitlement}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidentitlement',
                    value: uidentitlement,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_kpi_get = function (options, requestOptions) {
        return {
            path: '/portal/kpi',
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_owners_get = function (/** Object type of the entitlement */ tablename, /** UID of the entitlement */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/owners/{tablename}/{uid}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'tablename',
                    value: tablename,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_publish_application_post = function (uidapplication, date, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/publish/application/{uidapplication}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uidapplication',
                    value: uidapplication,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'date',
                    value: date,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shops_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shops',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_application_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_get(options), requestOptions);
    };
    V2Client.prototype.portal_application_delete = function (/** Application */ UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_delete(UID_AOBApplication, options), requestOptions);
    };
    /** Starts the entitlement mapping process for the specified application. */
    V2Client.prototype.portal_application_map_post = function (/** Unique application identifier */ UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_map_post(UID_AOBApplication, options), requestOptions);
    };
    /** Returns all identities having access to at least one entitlement of the application. */
    V2Client.prototype.portal_application_identities_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_identities_get(uidapplication, options), requestOptions);
    };
    /** Returns all entitlements that the specified identity has access to. */
    V2Client.prototype.portal_application_identitiesbyidentity_get = function (/** Unique application identifier */ uidapplication, /** Unique identity identifier */ uidperson, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_identitiesbyidentity_get(uidapplication, uidperson, options), requestOptions);
    };
    /** Returns application-specific KPI information. */
    V2Client.prototype.portal_application_kpi_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_kpi_get(uidapplication, options), requestOptions);
    };
    V2Client.prototype.portal_application_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_group_get(options), requestOptions);
    };
    V2Client.prototype.portal_application_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_application_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_delete(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_application_interactive_entitlementstoadd_get = function (entityid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_entitlementstoadd_get(entityid, options), requestOptions);
    };
    V2Client.prototype.portal_application_interactive_byid_get = function (/** Primary key value UID_AOBApplication */ UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_byid_get(UID_AOBApplication, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    V2Client.prototype.portal_application_interactive_UID_AERoleApprover_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleApprover_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the application/interactive/UID_AERoleApprover/candidates endpoint. */
    V2Client.prototype.portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleApprover_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    V2Client.prototype.portal_application_interactive_UID_AERoleOwner_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleOwner_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the application/interactive/UID_AERoleOwner/candidates endpoint. */
    V2Client.prototype.portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_application_new_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    V2Client.prototype.portal_application_new_UID_AccProductGroup_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AccProductGroup_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the application/new/UID_AccProductGroup/candidates endpoint. */
    V2Client.prototype.portal_application_new_UID_AccProductGroup_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AccProductGroup_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleApprover. */
    V2Client.prototype.portal_application_new_UID_AERoleApprover_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleApprover_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the application/new/UID_AERoleApprover/candidates endpoint. */
    V2Client.prototype.portal_application_new_UID_AERoleApprover_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleApprover_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    V2Client.prototype.portal_application_new_UID_AERoleOwner_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleOwner_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the application/new/UID_AERoleOwner/candidates endpoint. */
    V2Client.prototype.portal_application_new_UID_AERoleOwner_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_new_UID_AERoleOwner_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned as a filter parameter. */
    V2Client.prototype.portal_application_sqlwizard_candidates_get = function (/** Name of the candidate table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_sqlwizard_candidates_get(table, options), requestOptions);
    };
    /** Returns the filterable properties for the specified table. */
    V2Client.prototype.portal_application_sqlwizard_tables_columns_get = function (/** Name of the filtered database table */ table, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_application_sqlwizard_tables_columns_get(table, options), requestOptions);
    };
    V2Client.prototype.portal_applicationimage_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationimage_get(uidapplication, options), requestOptions);
    };
    V2Client.prototype.portal_applicationimage_post = function (/** Unique application identifier */ uidapplication, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationimage_post(uidapplication, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_applicationinshop_get = function (uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationinshop_get(uidapplication, options), requestOptions);
    };
    /** Assigns an application to a shop. */
    V2Client.prototype.portal_applicationinshop_put = function (uidapplication, uidshop, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationinshop_put(uidapplication, uidshop, inputParameterName, options), requestOptions);
    };
    /** Removes an application from a shop. */
    V2Client.prototype.portal_applicationinshop_delete = function (uidapplication, uidshop, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationinshop_delete(uidapplication, uidshop, inputParameterName, options), requestOptions);
    };
    /** Returns the list of accounts used by the specified application. */
    V2Client.prototype.portal_applicationusesaccount_get = function (UID_AOBApplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationusesaccount_get(UID_AOBApplication, options), requestOptions);
    };
    /** Returns the list of accounts used by the specified application. */
    V2Client.prototype.portal_applicationusesaccount_delete = function (UID_AOBApplication, /** Application: user account assignment */ UID_AOBAppUsesAccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationusesaccount_delete(UID_AOBApplication, UID_AOBAppUsesAccount, options), requestOptions);
    };
    /** Defines that an application uses a specific account. */
    V2Client.prototype.portal_applicationusesaccount_new_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_applicationusesaccount_new_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    V2Client.prototype.portal_candidates_AccProductParamCategory_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    V2Client.prototype.portal_candidates_AccProductParamCategory_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table AERole. */
    V2Client.prototype.portal_candidates_AERole_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/AERole endpoint. */
    V2Client.prototype.portal_candidates_AERole_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AERole_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table AOBApplication. */
    V2Client.prototype.portal_candidates_AOBApplication_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AOBApplication_get(options), requestOptions);
    };
    /** Returns data model information about query options for the candidates/AOBApplication endpoint. */
    V2Client.prototype.portal_candidates_AOBApplication_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AOBApplication_datamodel_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/AOBApplication endpoint. */
    V2Client.prototype.portal_candidates_AOBApplication_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_AOBApplication_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table Application. */
    V2Client.prototype.portal_candidates_Application_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Application_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/Application endpoint. */
    V2Client.prototype.portal_candidates_Application_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Application_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table ESet. */
    V2Client.prototype.portal_candidates_ESet_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_ESet_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/ESet endpoint. */
    V2Client.prototype.portal_candidates_ESet_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_ESet_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table FunctionalArea. */
    V2Client.prototype.portal_candidates_FunctionalArea_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_FunctionalArea_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/FunctionalArea endpoint. */
    V2Client.prototype.portal_candidates_FunctionalArea_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_FunctionalArea_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table Org. */
    V2Client.prototype.portal_candidates_Org_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/Org endpoint. */
    V2Client.prototype.portal_candidates_Org_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Org_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table Person. */
    V2Client.prototype.portal_candidates_Person_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/Person endpoint. */
    V2Client.prototype.portal_candidates_Person_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_Person_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERAssign. */
    V2Client.prototype.portal_candidates_QERAssign_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERAssign_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERAssign endpoint. */
    V2Client.prototype.portal_candidates_QERAssign_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERAssign_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERResource. */
    V2Client.prototype.portal_candidates_QERResource_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERResource_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERResource endpoint. */
    V2Client.prototype.portal_candidates_QERResource_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERResource_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERReuse. */
    V2Client.prototype.portal_candidates_QERReuse_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuse_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERReuse endpoint. */
    V2Client.prototype.portal_candidates_QERReuse_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuse_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERReuseUS. */
    V2Client.prototype.portal_candidates_QERReuseUS_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuseUS_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERReuseUS endpoint. */
    V2Client.prototype.portal_candidates_QERReuseUS_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERReuseUS_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table QERTermsOfUse. */
    V2Client.prototype.portal_candidates_QERTermsOfUse_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/QERTermsOfUse endpoint. */
    V2Client.prototype.portal_candidates_QERTermsOfUse_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_QERTermsOfUse_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table RPSReport. */
    V2Client.prototype.portal_candidates_RPSReport_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_RPSReport_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/RPSReport endpoint. */
    V2Client.prototype.portal_candidates_RPSReport_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_RPSReport_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table TSBAccountDef. */
    V2Client.prototype.portal_candidates_TSBAccountDef_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_TSBAccountDef_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/TSBAccountDef endpoint. */
    V2Client.prototype.portal_candidates_TSBAccountDef_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_TSBAccountDef_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table UNSAccountB. */
    V2Client.prototype.portal_candidates_UNSAccountB_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSAccountB_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/UNSAccountB endpoint. */
    V2Client.prototype.portal_candidates_UNSAccountB_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSAccountB_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table UNSGroup. */
    V2Client.prototype.portal_candidates_UNSGroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSGroup_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/UNSGroup endpoint. */
    V2Client.prototype.portal_candidates_UNSGroup_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSGroup_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of candidate objects from the table UNSRoot. */
    V2Client.prototype.portal_candidates_UNSRoot_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSRoot_get(options), requestOptions);
    };
    /** Returns filter tree information for the candidates/UNSRoot endpoint. */
    V2Client.prototype.portal_candidates_UNSRoot_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_candidates_UNSRoot_filtertree_post(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_delete = function (/** Entitlement */ UID_AOBEntitlement, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_delete(UID_AOBEntitlement, options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_systemrole_get = function (/** Unique application identifier */ uidapplication, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_systemrole_get(uidapplication, options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_group_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_interactive_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_interactive_delete = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_delete(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_interactive_byid_get = function (/** Primary key value UID_AOBEntitlement */ UID_AOBEntitlement, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_byid_get(UID_AOBEntitlement, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AERoleOwner. */
    V2Client.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_UID_AERoleOwner_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the entitlement/interactive/UID_AERoleOwner/candidates endpoint. */
    V2Client.prototype.portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_interactive_UID_AERoleOwner_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_serviceitem_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_serviceitem_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_entitlement_serviceitem_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the entitlement/serviceitem endpoint. */
    V2Client.prototype.portal_entitlement_serviceitem_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_datamodel_get(options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AccProductGroup. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_post(inputParameterName, options), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_AccProductGroup/candidates endpoint. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_AccProductGroup_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgAttestator/candidates endpoint. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgRuler_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_OrgRuler/candidates endpoint. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_get(options), requestOptions);
    };
    /** Returns filter tree information for the entitlement/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    V2Client.prototype.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName, options), requestOptions);
    };
    /** Adds entitlements to a new or existing system role, and adds the system role to the application. */
    V2Client.prototype.portal_entitlement_systemrole_post = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlement_systemrole_post(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_ESet_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_ESet_get(options), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/ESet endpoint. */
    V2Client.prototype.portal_entitlementcandidates_ESet_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_ESet_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_ESet_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_ESet_group_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_QERResource_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_QERResource_get(options), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/QERResource endpoint. */
    V2Client.prototype.portal_entitlementcandidates_QERResource_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_QERResource_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_QERResource_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_QERResource_group_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_RPSReport_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_RPSReport_get(options), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/RPSReport endpoint. */
    V2Client.prototype.portal_entitlementcandidates_RPSReport_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_RPSReport_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_RPSReport_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_RPSReport_group_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_TSBAccountDef_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_TSBAccountDef_get(options), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/TSBAccountDef endpoint. */
    V2Client.prototype.portal_entitlementcandidates_TSBAccountDef_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_TSBAccountDef_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_TSBAccountDef_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_TSBAccountDef_group_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_UNSGroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_get(options), requestOptions);
    };
    /** Returns data model information about query options for the entitlementcandidates/UNSGroup endpoint. */
    V2Client.prototype.portal_entitlementcandidates_UNSGroup_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_datamodel_get(options), requestOptions);
    };
    /** Returns filter tree information for the entitlementcandidates/UNSGroup endpoint. */
    V2Client.prototype.portal_entitlementcandidates_UNSGroup_filtertree_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_filtertree_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementcandidates_UNSGroup_group_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementcandidates_UNSGroup_group_get(options), requestOptions);
    };
    V2Client.prototype.portal_entitlementimage_get = function (/** Unique entitlement identifier */ uidentitlement, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementimage_get(uidentitlement, options), requestOptions);
    };
    V2Client.prototype.portal_entitlementimage_post = function (/** Unique entitlement identifier */ uidentitlement, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_entitlementimage_post(uidentitlement, inputParameterName, options), requestOptions);
    };
    /** Returns global KPI information for application governance. */
    V2Client.prototype.portal_kpi_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_kpi_get(options), requestOptions);
    };
    /** Returns owner information for the specified entitlement */
    V2Client.prototype.portal_owners_get = function (/** Object type of the entitlement */ tablename, /** UID of the entitlement */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_owners_get(tablename, uid, options), requestOptions);
    };
    V2Client.prototype.portal_publish_application_post = function (uidapplication, date, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_publish_application_post(uidapplication, date, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_shops_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shops_get(options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalApplication, PortalApplicationIdentities, PortalApplicationIdentitiesInteractive, PortalApplicationIdentitiesWrapper, PortalApplicationIdentitiesbyidentity, PortalApplicationIdentitiesbyidentityInteractive, PortalApplicationIdentitiesbyidentityWrapper, PortalApplicationInteractive, PortalApplicationInteractiveWrapper, PortalApplicationNew, PortalApplicationNewInteractive, PortalApplicationNewWrapper, PortalApplicationSqlwizardCandidates, PortalApplicationSqlwizardCandidatesInteractive, PortalApplicationSqlwizardCandidatesWrapper, PortalApplicationWrapper, PortalApplicationinshop, PortalApplicationinshopInteractive, PortalApplicationinshopWrapper, PortalApplicationusesaccount, PortalApplicationusesaccountInteractive, PortalApplicationusesaccountNew, PortalApplicationusesaccountNewInteractive, PortalApplicationusesaccountNewWrapper, PortalApplicationusesaccountWrapper, PortalCandidatesAccproductparamcategory, PortalCandidatesAccproductparamcategoryInteractive, PortalCandidatesAccproductparamcategoryWrapper, PortalCandidatesAerole, PortalCandidatesAeroleInteractive, PortalCandidatesAeroleWrapper, PortalCandidatesAobapplication, PortalCandidatesAobapplicationInteractive, PortalCandidatesAobapplicationWrapper, PortalCandidatesApplication, PortalCandidatesApplicationInteractive, PortalCandidatesApplicationWrapper, PortalCandidatesEset, PortalCandidatesEsetInteractive, PortalCandidatesEsetWrapper, PortalCandidatesFunctionalarea, PortalCandidatesFunctionalareaInteractive, PortalCandidatesFunctionalareaWrapper, PortalCandidatesOrg, PortalCandidatesOrgInteractive, PortalCandidatesOrgWrapper, PortalCandidatesPerson, PortalCandidatesPersonInteractive, PortalCandidatesPersonWrapper, PortalCandidatesQerassign, PortalCandidatesQerassignInteractive, PortalCandidatesQerassignWrapper, PortalCandidatesQerresource, PortalCandidatesQerresourceInteractive, PortalCandidatesQerresourceWrapper, PortalCandidatesQerreuse, PortalCandidatesQerreuseInteractive, PortalCandidatesQerreuseWrapper, PortalCandidatesQerreuseus, PortalCandidatesQerreuseusInteractive, PortalCandidatesQerreuseusWrapper, PortalCandidatesQertermsofuse, PortalCandidatesQertermsofuseInteractive, PortalCandidatesQertermsofuseWrapper, PortalCandidatesRpsreport, PortalCandidatesRpsreportInteractive, PortalCandidatesRpsreportWrapper, PortalCandidatesTsbaccountdef, PortalCandidatesTsbaccountdefInteractive, PortalCandidatesTsbaccountdefWrapper, PortalCandidatesUnsaccountb, PortalCandidatesUnsaccountbInteractive, PortalCandidatesUnsaccountbWrapper, PortalCandidatesUnsgroup, PortalCandidatesUnsgroupInteractive, PortalCandidatesUnsgroupWrapper, PortalCandidatesUnsroot, PortalCandidatesUnsrootInteractive, PortalCandidatesUnsrootWrapper, PortalEntitlement, PortalEntitlementInteractive, PortalEntitlementInteractiveWrapper, PortalEntitlementServiceitem, PortalEntitlementServiceitemInteractive, PortalEntitlementServiceitemWrapper, PortalEntitlementSystemrole, PortalEntitlementSystemroleInteractive, PortalEntitlementSystemroleWrapper, PortalEntitlementWrapper, PortalEntitlementcandidatesEset, PortalEntitlementcandidatesEsetInteractive, PortalEntitlementcandidatesEsetWrapper, PortalEntitlementcandidatesQerresource, PortalEntitlementcandidatesQerresourceInteractive, PortalEntitlementcandidatesQerresourceWrapper, PortalEntitlementcandidatesRpsreport, PortalEntitlementcandidatesRpsreportInteractive, PortalEntitlementcandidatesRpsreportWrapper, PortalEntitlementcandidatesTsbaccountdef, PortalEntitlementcandidatesTsbaccountdefInteractive, PortalEntitlementcandidatesTsbaccountdefWrapper, PortalEntitlementcandidatesUnsgroup, PortalEntitlementcandidatesUnsgroupInteractive, PortalEntitlementcandidatesUnsgroupWrapper, PortalOwners, PortalOwnersInteractive, PortalOwnersWrapper, PortalShops, PortalShopsInteractive, PortalShopsWrapper, StatisticAggregateFunction, StatisticTimeScaleUnit, TypedClient, V2ApiClientMethodFactory, V2Client };
