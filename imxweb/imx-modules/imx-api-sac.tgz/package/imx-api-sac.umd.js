(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.PortalSapgrpMemberships = new PortalSapgrpMembershipsWrapper(client, translationProvider);
            this.PortalSapprofileMemberships = new PortalSapprofileMembershipsWrapper(client, translationProvider);
            this.PortalSaproleMemberships = new PortalSaproleMembershipsWrapper(client, translationProvider);
            this.PortalTargetsystemSapgrp = new PortalTargetsystemSapgrpWrapper(client, translationProvider);
            this.PortalTargetsystemSapgrpInteractive = new PortalTargetsystemSapgrpInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemSapprofile = new PortalTargetsystemSapprofileWrapper(client, translationProvider);
            this.PortalTargetsystemSapprofileInteractive = new PortalTargetsystemSapprofileInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemSaprole = new PortalTargetsystemSaproleWrapper(client, translationProvider);
            this.PortalTargetsystemSaproleInteractive = new PortalTargetsystemSaproleInteractiveWrapper(client, translationProvider);
            this.PortalTargetsystemSapuser = new PortalTargetsystemSapuserWrapper(client, translationProvider);
            this.PortalTargetsystemSapuserInteractive = new PortalTargetsystemSapuserInteractiveWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var PortalSapgrpMemberships = /** @class */ (function (_super) {
        __extends(PortalSapgrpMemberships, _super);
        function PortalSapgrpMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalSapgrpMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalSapgrpMemberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalSapgrpMemberships type. */
    var PortalSapgrpMembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalSapgrpMembershipsInteractive, _super);
        function PortalSapgrpMembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalSapgrpMembershipsInteractive;
    }(PortalSapgrpMemberships));
    var PortalSapprofileMemberships = /** @class */ (function (_super) {
        __extends(PortalSapprofileMemberships, _super);
        function PortalSapprofileMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalSapprofileMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalSapprofileMemberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalSapprofileMemberships type. */
    var PortalSapprofileMembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalSapprofileMembershipsInteractive, _super);
        function PortalSapprofileMembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalSapprofileMembershipsInteractive;
    }(PortalSapprofileMemberships));
    var PortalSaproleMemberships = /** @class */ (function (_super) {
        __extends(PortalSaproleMemberships, _super);
        function PortalSaproleMemberships() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.IsPending = _this.GetEntityValue('IsPending');
            _this.IsPrimary = _this.GetEntityValue('IsPrimary');
            _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.OrderState = _this.GetEntityValue('OrderState');
            _this.ValidUntil = _this.GetEntityValue('ValidUntil');
            _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
            _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalSaproleMemberships.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAssignment': {
                    ColumnName: 'ObjectKeyAssignment',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsPending': {
                    ColumnName: 'IsPending',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrimary': {
                    ColumnName: 'IsPrimary',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XMarkedForDeletion': {
                    ColumnName: 'XMarkedForDeletion',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'OrderState': {
                    ColumnName: 'OrderState',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ValidUntil': {
                    ColumnName: 'ValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_UNSAccount': {
                    ColumnName: 'UID_UNSAccount',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UNSGroupChild': {
                    ColumnName: 'UID_UNSGroupChild',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return PortalSaproleMemberships;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalSaproleMemberships type. */
    var PortalSaproleMembershipsInteractive = /** @class */ (function (_super) {
        __extends(PortalSaproleMembershipsInteractive, _super);
        function PortalSaproleMembershipsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalSaproleMembershipsInteractive;
    }(PortalSaproleMemberships));
    var PortalTargetsystemSapgrp = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSapgrp, _super);
        function PortalTargetsystemSapgrp() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemSapgrp.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XReadOnlyMemberships': {
                    ColumnName: 'XReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'SAPGrp', Columns: columns };
        };
        return PortalTargetsystemSapgrp;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemSapgrp type. */
    var PortalTargetsystemSapgrpInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSapgrpInteractive, _super);
        function PortalTargetsystemSapgrpInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemSapgrpInteractive;
    }(PortalTargetsystemSapgrp));
    var PortalTargetsystemSapprofile = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSapprofile, _super);
        function PortalTargetsystemSapprofile() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemSapprofile.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XReadOnlyMemberships': {
                    ColumnName: 'XReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'SAPProfile', Columns: columns };
        };
        return PortalTargetsystemSapprofile;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemSapprofile type. */
    var PortalTargetsystemSapprofileInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSapprofileInteractive, _super);
        function PortalTargetsystemSapprofileInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemSapprofileInteractive;
    }(PortalTargetsystemSapprofile));
    var PortalTargetsystemSaprole = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSaprole, _super);
        function PortalTargetsystemSaprole() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.Requestable = _this.GetEntityValue('Requestable');
            _this.Owned = _this.GetEntityValue('Owned');
            _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemSaprole.GetEntitySchema = function () {
            var columns = {
                'UID_AccProduct': {
                    ColumnName: 'UID_AccProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Requestable': {
                    ColumnName: 'Requestable',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Owned': {
                    ColumnName: 'Owned',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XReadOnlyMemberships': {
                    ColumnName: 'XReadOnlyMemberships',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'SAPRole', Columns: columns };
        };
        return PortalTargetsystemSaprole;
    }(imxQbmDbts.WriteExtTypedEntity));
    /** @deprecated Use the PortalTargetsystemSaprole type. */
    var PortalTargetsystemSaproleInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSaproleInteractive, _super);
        function PortalTargetsystemSaproleInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemSaproleInteractive;
    }(PortalTargetsystemSaprole));
    var PortalTargetsystemSapuser = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSapuser, _super);
        function PortalTargetsystemSapuser() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        /** Returns the static compile time schema for this type. */
        PortalTargetsystemSapuser.GetEntitySchema = function () {
            var columns = {};
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'SAPUser', Columns: columns };
        };
        return PortalTargetsystemSapuser;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalTargetsystemSapuser type. */
    var PortalTargetsystemSapuserInteractive = /** @class */ (function (_super) {
        __extends(PortalTargetsystemSapuserInteractive, _super);
        function PortalTargetsystemSapuserInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalTargetsystemSapuserInteractive;
    }(PortalTargetsystemSapuser));
    var PortalSapgrpMembershipsWrapper = /** @class */ (function () {
        function PortalSapgrpMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalSapgrpMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/SAPGrp/{uid}/memberships');
        };
        PortalSapgrpMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/SAPGrp/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalSapgrpMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalSapgrpMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_SAPGrp_memberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalSapgrpMembershipsWrapper;
    }());
    var PortalSapprofileMembershipsWrapper = /** @class */ (function () {
        function PortalSapprofileMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalSapprofileMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/SAPProfile/{uid}/memberships');
        };
        PortalSapprofileMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/SAPProfile/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalSapprofileMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalSapprofileMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_SAPProfile_memberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalSapprofileMembershipsWrapper;
    }());
    var PortalSaproleMembershipsWrapper = /** @class */ (function () {
        function PortalSaproleMembershipsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalSaproleMembershipsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/SAPRole/{uid}/memberships');
        };
        PortalSaproleMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/SAPRole/{uid}/memberships');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalSaproleMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalSaproleMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_SAPRole_memberships_get(uid, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalSaproleMembershipsWrapper;
    }());
    var PortalTargetsystemSapgrpWrapper = /** @class */ (function () {
        function PortalTargetsystemSapgrpWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_sapgrp_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSapgrpWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/sapgrp');
        };
        PortalTargetsystemSapgrpWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/sapgrp');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemSapgrp, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSapgrpWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapgrp_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSapgrpWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapgrp_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSapgrpWrapper;
    }());
    var PortalTargetsystemSapgrpInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemSapgrpInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_sapgrp_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSapgrpInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/sapgrp/interactive');
        };
        PortalTargetsystemSapgrpInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/sapgrp/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemSapgrp, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSapgrpInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapgrp_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSapgrpInteractiveWrapper.prototype.Get_byid = function (UID_SAPGrp, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapgrp_interactive_byid_get(UID_SAPGrp, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSapgrpInteractiveWrapper;
    }());
    var PortalTargetsystemSapprofileWrapper = /** @class */ (function () {
        function PortalTargetsystemSapprofileWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_sapprofile_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSapprofileWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/sapprofile');
        };
        PortalTargetsystemSapprofileWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/sapprofile');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemSapprofile, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSapprofileWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapprofile_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSapprofileWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapprofile_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSapprofileWrapper;
    }());
    var PortalTargetsystemSapprofileInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemSapprofileInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_sapprofile_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSapprofileInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/sapprofile/interactive');
        };
        PortalTargetsystemSapprofileInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/sapprofile/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemSapprofile, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSapprofileInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapprofile_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSapprofileInteractiveWrapper.prototype.Get_byid = function (UID_SAPProfile, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapprofile_interactive_byid_get(UID_SAPProfile, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSapprofileInteractiveWrapper;
    }());
    var PortalTargetsystemSaproleWrapper = /** @class */ (function () {
        function PortalTargetsystemSaproleWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_saprole_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSaproleWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/saprole');
        };
        PortalTargetsystemSaproleWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/saprole');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemSaprole, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSaproleWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_saprole_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSaproleWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_saprole_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSaproleWrapper;
    }());
    var PortalTargetsystemSaproleInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemSaproleInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_saprole_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSaproleInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/saprole/interactive');
        };
        PortalTargetsystemSaproleInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/saprole/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemSaprole, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSaproleInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_saprole_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSaproleInteractiveWrapper.prototype.Get_byid = function (UID_SAPRole, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_saprole_interactive_byid_get(UID_SAPRole, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSaproleInteractiveWrapper;
    }());
    var PortalTargetsystemSapuserWrapper = /** @class */ (function () {
        function PortalTargetsystemSapuserWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_sapuser_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSapuserWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/sapuser');
        };
        PortalTargetsystemSapuserWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/sapuser');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalTargetsystemSapuser, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSapuserWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapuser_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSapuserWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapuser_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSapuserWrapper;
    }());
    var PortalTargetsystemSapuserInteractiveWrapper = /** @class */ (function () {
        function PortalTargetsystemSapuserInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_targetsystem_sapuser_interactive_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalTargetsystemSapuserInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/targetsystem/sapuser/interactive');
        };
        PortalTargetsystemSapuserInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/sapuser/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalTargetsystemSapuser, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalTargetsystemSapuserInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapuser_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalTargetsystemSapuserInteractiveWrapper.prototype.Get_byid = function (UID_SAPUser, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_targetsystem_sapuser_interactive_byid_get(UID_SAPUser, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalTargetsystemSapuserInteractiveWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.portal_sap_ruleanalysis_byrole_get = function (uidsapuser, uidcompliancerule) {
            return {
                path: '/portal/sap/ruleanalysis/{uidsapuser}/{uidcompliancerule}/byrole',
                parameters: [
                    {
                        name: 'uidsapuser',
                        value: uidsapuser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidcompliancerule',
                        value: uidcompliancerule,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_sap_ruleanalysis_fld_get = function (uidsapuser, uidcompliancerule) {
            return {
                path: '/portal/sap/ruleanalysis/{uidsapuser}/{uidcompliancerule}/fld',
                parameters: [
                    {
                        name: 'uidsapuser',
                        value: uidsapuser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidcompliancerule',
                        value: uidcompliancerule,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_sap_ruleanalysis_prof_get = function (uidsapuser, uidcompliancerule) {
            return {
                path: '/portal/sap/ruleanalysis/{uidsapuser}/{uidcompliancerule}/prof',
                parameters: [
                    {
                        name: 'uidsapuser',
                        value: uidsapuser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidcompliancerule',
                        value: uidcompliancerule,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_SAPGrp_memberships_get = function (uid) {
            return {
                path: '/portal/SAPGrp/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_SAPGrp_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/SAPGrp/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_SAPProfile_memberships_get = function (uid) {
            return {
                path: '/portal/SAPProfile/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_SAPProfile_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/SAPProfile/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_SAPRole_memberships_get = function (uid) {
            return {
                path: '/portal/SAPRole/{uid}/memberships',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_SAPRole_memberships_delete = function (uid, uidaccount) {
            return {
                path: '/portal/SAPRole/{uid}/memberships/{uidaccount}',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates/datamodel',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/sapgrp',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapgrp',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapgrp/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/sapgrp/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapgrp/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_interactive_byid_get = function (UID_SAPGrp) {
            return {
                path: '/portal/targetsystem/sapgrp/interactive/{UID_SAPGrp}',
                parameters: [
                    {
                        name: 'UID_SAPGrp',
                        value: UID_SAPGrp,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/sapprofile',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapprofile',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapprofile/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/sapprofile/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapprofile/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_interactive_byid_get = function (UID_SAPProfile) {
            return {
                path: '/portal/targetsystem/sapprofile/interactive/{UID_SAPProfile}',
                parameters: [
                    {
                        name: 'UID_SAPProfile',
                        value: UID_SAPProfile,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_saprole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/saprole',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'published',
                        value: published,
                        in: 'query'
                    },
                    {
                        name: 'withowner',
                        value: withowner,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_saprole_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/saprole',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_saprole_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/saprole/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_saprole_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/saprole/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_saprole_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/saprole/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_saprole_interactive_byid_get = function (UID_SAPRole) {
            return {
                path: '/portal/targetsystem/saprole/interactive/{UID_SAPRole}',
                parameters: [
                    {
                        name: 'UID_SAPRole',
                        value: UID_SAPRole,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk) {
            return {
                path: '/portal/targetsystem/sapuser',
                parameters: [
                    {
                        name: 'UID_PersonAssociated',
                        value: UID_PersonAssociated,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'orphaned',
                        value: orphaned,
                        in: 'query'
                    },
                    {
                        name: 'deletedintarget',
                        value: deletedintarget,
                        in: 'query'
                    },
                    {
                        name: 'risk',
                        value: risk,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapuser',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_bulk_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapuser/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_datamodel_get = function (filter) {
            return {
                path: '/portal/targetsystem/sapuser/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_interactive_put = function (inputParameterName) {
            return {
                path: '/portal/targetsystem/sapuser/interactive',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_interactive_byid_get = function (UID_SAPUser) {
            return {
                path: '/portal/targetsystem/sapuser/interactive/{UID_SAPUser}',
                parameters: [
                    {
                        name: 'UID_SAPUser',
                        value: UID_SAPUser,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        Client.prototype.portal_sap_ruleanalysis_byrole_get = function (uidsapuser, uidcompliancerule, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_sap_ruleanalysis_byrole_get(uidsapuser, uidcompliancerule), requestOptions);
        };
        Client.prototype.portal_sap_ruleanalysis_fld_get = function (uidsapuser, uidcompliancerule, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_sap_ruleanalysis_fld_get(uidsapuser, uidcompliancerule), requestOptions);
        };
        Client.prototype.portal_sap_ruleanalysis_prof_get = function (uidsapuser, uidcompliancerule, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_sap_ruleanalysis_prof_get(uidsapuser, uidcompliancerule), requestOptions);
        };
        Client.prototype.portal_SAPGrp_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPGrp_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_SAPGrp_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPGrp_memberships_delete(uid, uidaccount), requestOptions);
        };
        Client.prototype.portal_SAPProfile_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPProfile_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_SAPProfile_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPProfile_memberships_delete(uid, uidaccount), requestOptions);
        };
        Client.prototype.portal_SAPRole_memberships_get = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPRole_memberships_get(uid), requestOptions);
        };
        /** Deletes an account membership. */
        Client.prototype.portal_SAPRole_memberships_delete = function (uid, uidaccount, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPRole_memberships_delete(uid, uidaccount), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_SAPGrp. */
        Client.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_SAPProfile. */
        Client.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_SAPRole. */
        Client.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
        Client.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapgrp_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapgrp_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapgrp_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/sapgrp endpoint. */
        Client.prototype.portal_targetsystem_sapgrp_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapgrp_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapgrp_interactive_byid_get = function (UID_SAPGrp, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_interactive_byid_get(UID_SAPGrp), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapprofile_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapprofile_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapprofile_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/sapprofile endpoint. */
        Client.prototype.portal_targetsystem_sapprofile_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapprofile_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapprofile_interactive_byid_get = function (UID_SAPProfile, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_interactive_byid_get(UID_SAPProfile), requestOptions);
        };
        Client.prototype.portal_targetsystem_saprole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_saprole_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_saprole_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/saprole endpoint. */
        Client.prototype.portal_targetsystem_saprole_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_saprole_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_saprole_interactive_byid_get = function (UID_SAPRole, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_interactive_byid_get(UID_SAPRole), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapuser_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_get(UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapuser_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapuser_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/sapuser endpoint. */
        Client.prototype.portal_targetsystem_sapuser_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapuser_interactive_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_interactive_put(inputParameterName), requestOptions);
        };
        Client.prototype.portal_targetsystem_sapuser_interactive_byid_get = function (UID_SAPUser, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_interactive_byid_get(UID_SAPUser), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.portal_sap_ruleanalysis_byrole_get = function (uidsapuser, uidcompliancerule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/sap/ruleanalysis/{uidsapuser}/{uidcompliancerule}/byrole',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidsapuser',
                        value: uidsapuser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidcompliancerule',
                        value: uidcompliancerule,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_sap_ruleanalysis_fld_get = function (uidsapuser, uidcompliancerule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/sap/ruleanalysis/{uidsapuser}/{uidcompliancerule}/fld',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidsapuser',
                        value: uidsapuser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidcompliancerule',
                        value: uidcompliancerule,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_sap_ruleanalysis_prof_get = function (uidsapuser, uidcompliancerule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/sap/ruleanalysis/{uidsapuser}/{uidcompliancerule}/prof',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidsapuser',
                        value: uidsapuser,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidcompliancerule',
                        value: uidcompliancerule,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_SAPGrp_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/SAPGrp/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_SAPGrp_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/SAPGrp/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_SAPProfile_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/SAPProfile/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_SAPProfile_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/SAPProfile/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_SAPRole_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/SAPRole/{uid}/memberships',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_SAPRole_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/SAPRole/{uid}/memberships/{uidaccount}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidaccount',
                        value: uidaccount,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ITShopOrg',
                        value: UID_ITShopOrg,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapgrp',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapgrp',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapgrp/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapgrp/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapgrp/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapgrp_interactive_byid_get = function (/** Primary key value UID_SAPGrp */ UID_SAPGrp, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapgrp/interactive/{UID_SAPGrp}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_SAPGrp',
                        value: UID_SAPGrp,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapprofile',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapprofile',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapprofile/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapprofile/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapprofile/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapprofile_interactive_byid_get = function (/** Primary key value UID_SAPProfile */ UID_SAPProfile, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapprofile/interactive/{UID_SAPProfile}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_SAPProfile',
                        value: UID_SAPProfile,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_saprole_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/saprole',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_saprole_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/saprole',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_saprole_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/saprole/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_saprole_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/saprole/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_saprole_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/saprole/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_saprole_interactive_byid_get = function (/** Primary key value UID_SAPRole */ UID_SAPRole, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/saprole/interactive/{UID_SAPRole}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_SAPRole',
                        value: UID_SAPRole,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapuser',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapuser',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapuser/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapuser/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapuser/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_targetsystem_sapuser_interactive_byid_get = function (/** Primary key value UID_SAPUser */ UID_SAPUser, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/targetsystem/sapuser/interactive/{UID_SAPUser}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_SAPUser',
                        value: UID_SAPUser,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        V2Client.prototype.portal_sap_ruleanalysis_byrole_get = function (uidsapuser, uidcompliancerule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_sap_ruleanalysis_byrole_get(uidsapuser, uidcompliancerule, options), requestOptions);
        };
        V2Client.prototype.portal_sap_ruleanalysis_fld_get = function (uidsapuser, uidcompliancerule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_sap_ruleanalysis_fld_get(uidsapuser, uidcompliancerule, options), requestOptions);
        };
        V2Client.prototype.portal_sap_ruleanalysis_prof_get = function (uidsapuser, uidcompliancerule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_sap_ruleanalysis_prof_get(uidsapuser, uidcompliancerule, options), requestOptions);
        };
        V2Client.prototype.portal_SAPGrp_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPGrp_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_SAPGrp_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPGrp_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        V2Client.prototype.portal_SAPProfile_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPProfile_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_SAPProfile_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPProfile_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        V2Client.prototype.portal_SAPRole_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPRole_memberships_get(uid, options), requestOptions);
        };
        /** Deletes an account membership. */
        V2Client.prototype.portal_SAPRole_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_SAPRole_memberships_delete(uid, uidaccount, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_SAPGrp. */
        V2Client.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPGrp/UID_SAPGrp/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPGrp_UID_SAPGrp_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_SAPProfile. */
        V2Client.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPProfile/UID_SAPProfile/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPProfile_UID_SAPProfile_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_SAPRole. */
        V2Client.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
        };
        /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/SAPRole/UID_SAPRole/candidates endpoint. */
        V2Client.prototype.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_SAPRole_UID_SAPRole_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapgrp_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapgrp_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapgrp_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/sapgrp endpoint. */
        V2Client.prototype.portal_targetsystem_sapgrp_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapgrp_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapgrp_interactive_byid_get = function (/** Primary key value UID_SAPGrp */ UID_SAPGrp, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapgrp_interactive_byid_get(UID_SAPGrp, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapprofile_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapprofile_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapprofile_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/sapprofile endpoint. */
        V2Client.prototype.portal_targetsystem_sapprofile_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapprofile_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapprofile_interactive_byid_get = function (/** Primary key value UID_SAPProfile */ UID_SAPProfile, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapprofile_interactive_byid_get(UID_SAPProfile, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_saprole_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_saprole_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_saprole_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/saprole endpoint. */
        V2Client.prototype.portal_targetsystem_saprole_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_saprole_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_saprole_interactive_byid_get = function (/** Primary key value UID_SAPRole */ UID_SAPRole, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_saprole_interactive_byid_get(UID_SAPRole, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapuser_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapuser_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapuser_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the targetsystem/sapuser endpoint. */
        V2Client.prototype.portal_targetsystem_sapuser_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapuser_interactive_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_interactive_put(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_targetsystem_sapuser_interactive_byid_get = function (/** Primary key value UID_SAPUser */ UID_SAPUser, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_sapuser_interactive_byid_get(UID_SAPUser, options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.PortalSapgrpMemberships = PortalSapgrpMemberships;
    exports.PortalSapgrpMembershipsInteractive = PortalSapgrpMembershipsInteractive;
    exports.PortalSapgrpMembershipsWrapper = PortalSapgrpMembershipsWrapper;
    exports.PortalSapprofileMemberships = PortalSapprofileMemberships;
    exports.PortalSapprofileMembershipsInteractive = PortalSapprofileMembershipsInteractive;
    exports.PortalSapprofileMembershipsWrapper = PortalSapprofileMembershipsWrapper;
    exports.PortalSaproleMemberships = PortalSaproleMemberships;
    exports.PortalSaproleMembershipsInteractive = PortalSaproleMembershipsInteractive;
    exports.PortalSaproleMembershipsWrapper = PortalSaproleMembershipsWrapper;
    exports.PortalTargetsystemSapgrp = PortalTargetsystemSapgrp;
    exports.PortalTargetsystemSapgrpInteractive = PortalTargetsystemSapgrpInteractive;
    exports.PortalTargetsystemSapgrpInteractiveWrapper = PortalTargetsystemSapgrpInteractiveWrapper;
    exports.PortalTargetsystemSapgrpWrapper = PortalTargetsystemSapgrpWrapper;
    exports.PortalTargetsystemSapprofile = PortalTargetsystemSapprofile;
    exports.PortalTargetsystemSapprofileInteractive = PortalTargetsystemSapprofileInteractive;
    exports.PortalTargetsystemSapprofileInteractiveWrapper = PortalTargetsystemSapprofileInteractiveWrapper;
    exports.PortalTargetsystemSapprofileWrapper = PortalTargetsystemSapprofileWrapper;
    exports.PortalTargetsystemSaprole = PortalTargetsystemSaprole;
    exports.PortalTargetsystemSaproleInteractive = PortalTargetsystemSaproleInteractive;
    exports.PortalTargetsystemSaproleInteractiveWrapper = PortalTargetsystemSaproleInteractiveWrapper;
    exports.PortalTargetsystemSaproleWrapper = PortalTargetsystemSaproleWrapper;
    exports.PortalTargetsystemSapuser = PortalTargetsystemSapuser;
    exports.PortalTargetsystemSapuserInteractive = PortalTargetsystemSapuserInteractive;
    exports.PortalTargetsystemSapuserInteractiveWrapper = PortalTargetsystemSapuserInteractiveWrapper;
    exports.PortalTargetsystemSapuserWrapper = PortalTargetsystemSapuserWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
