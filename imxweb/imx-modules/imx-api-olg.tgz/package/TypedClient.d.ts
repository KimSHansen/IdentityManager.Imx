import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityWriteData, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, MethodDescriptor, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface ActivateFactorData {
    auth_factor_name?: string;
    type_display_name?: string;
    user_display_name?: string;
    id?: string;
    user_id?: string;
    expires_at: Date;
    device_id?: string;
}
export interface AuthFactor {
    Display?: string;
    Name?: string;
    Id?: string;
    FactorId?: string;
}
export interface AuthFactors {
    Factors?: AuthFactor[];
    DefaultId?: string;
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityWriteDataOfGroupExtendedData extends EntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface ExtendedInteractiveEntityWriteDataOfGroupExtendedData extends InteractiveEntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface GroupExtendedData {
    CreateServiceItem: boolean;
}
export declare enum VerifyPollingResult {
    Expired = 0,
    Accepted = 1,
    Rejected = 2
}
export declare class TypedClient {
    readonly PortalOlgapplicationMemberships: PortalOlgapplicationMembershipsWrapper;
    readonly PortalOlgroleMemberships: PortalOlgroleMembershipsWrapper;
    readonly PortalTargetsystemOlgapplication: PortalTargetsystemOlgapplicationWrapper;
    readonly PortalTargetsystemOlgapplicationInteractive: PortalTargetsystemOlgapplicationInteractiveWrapper;
    readonly PortalTargetsystemOlgrole: PortalTargetsystemOlgroleWrapper;
    readonly PortalTargetsystemOlgroleInteractive: PortalTargetsystemOlgroleInteractiveWrapper;
    readonly PortalTargetsystemOlguser: PortalTargetsystemOlguserWrapper;
    readonly PortalTargetsystemOlguserInteractive: PortalTargetsystemOlguserInteractiveWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalOlgapplicationMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalOlgapplicationMemberships type. */
export declare class PortalOlgapplicationMembershipsInteractive extends PortalOlgapplicationMemberships {
}
export declare class PortalOlgroleMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalOlgroleMemberships type. */
export declare class PortalOlgroleMembershipsInteractive extends PortalOlgroleMemberships {
}
export declare class PortalTargetsystemOlgapplication extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemOlgapplication type. */
export declare class PortalTargetsystemOlgapplicationInteractive extends PortalTargetsystemOlgapplication {
}
export declare class PortalTargetsystemOlgrole extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemOlgrole type. */
export declare class PortalTargetsystemOlgroleInteractive extends PortalTargetsystemOlgrole {
}
export declare class PortalTargetsystemOlguser extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemOlguser type. */
export declare class PortalTargetsystemOlguserInteractive extends PortalTargetsystemOlguser {
}
export declare class PortalOlgapplicationMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalOlgapplicationMemberships, unknown>>;
}
export declare class PortalOlgroleMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalOlgroleMemberships, unknown>>;
}
export declare class PortalTargetsystemOlgapplicationWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_olgapplication_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgapplication, unknown>>;
    Put(inputParameterName: PortalTargetsystemOlgapplication, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgapplication, unknown>>;
}
export declare class PortalTargetsystemOlgapplicationInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemOlgapplication, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgapplication, unknown>>;
    Get_byid(UID_OLGApplication: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgapplication, unknown>>;
}
export declare class PortalTargetsystemOlgroleWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_olgrole_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgrole, unknown>>;
    Put(inputParameterName: PortalTargetsystemOlgrole, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgrole, unknown>>;
}
export declare class PortalTargetsystemOlgroleInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemOlgrole, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgrole, unknown>>;
    Get_byid(UID_OLGRole: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlgrole, unknown>>;
}
export declare class PortalTargetsystemOlguserWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_olguser_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlguser, unknown>>;
    Put(inputParameterName: PortalTargetsystemOlguser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlguser, unknown>>;
}
export declare class PortalTargetsystemOlguserInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemOlguser, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlguser, unknown>>;
    Get_byid(UID_OLGUser: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemOlguser, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_OLGApplication_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_OLGApplication_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_OLGRole_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_OLGRole_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_onelogin_mfa_activate_post(workflowActionId: string, deviceid: string): MethodDescriptor<ActivateFactorData>;
    portal_onelogin_mfa_poll_get(workflowActionId: string, verificationid: string, deviceid: string): MethodDescriptor<VerifyPollingResult>;
    portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId: string, verificationid: string, deviceid: string, inputParameterName: string): MethodDescriptor<boolean>;
    portal_onelogin_mfa_factors_get(): MethodDescriptor<AuthFactors>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_olgapplication_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgapplication_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgapplication_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_olgapplication_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_olgapplication_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olgapplication_interactive_byid_get(UID_OLGApplication: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olgrole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgrole_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_olgrole_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_olgrole_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olgrole_interactive_byid_get(UID_OLGRole: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olguser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olguser_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olguser_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_olguser_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_olguser_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olguser_interactive_byid_get(UID_OLGUser: string): MethodDescriptor<InteractiveEntityData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_OLGApplication_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGApplication_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_OLGRole_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGRole_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Activates the given factor. */
    portal_onelogin_mfa_activate_post(workflowActionId: string, deviceid: string, requestOptions?: ApiRequestOptions): Promise<ActivateFactorData>;
    /** Waits for a confirmation of the factor. */
    portal_onelogin_mfa_poll_get(workflowActionId: string, verificationid: string, deviceid: string, requestOptions?: ApiRequestOptions): Promise<VerifyPollingResult>;
    /** Verifies the supplied one-time password. */
    portal_onelogin_mfa_verifyotpwithverificationid_post(workflowActionId: string, verificationid: string, deviceid: string, inputParameterName: string, requestOptions?: ApiRequestOptions): Promise<boolean>;
    /** Returns the enrolled factors for the user. */
    portal_onelogin_mfa_factors_get(requestOptions?: ApiRequestOptions): Promise<AuthFactors>;
    /** Returns a list of objects that can be assigned to the property UID_OLGApplication. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OLGRole. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_olgapplication_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgapplication_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgapplication_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/olgapplication endpoint. */
    portal_targetsystem_olgapplication_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_olgapplication_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olgapplication_interactive_byid_get(UID_OLGApplication: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olgrole_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgrole_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/olgrole endpoint. */
    portal_targetsystem_olgrole_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_olgrole_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olgrole_interactive_byid_get(UID_OLGRole: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olguser_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olguser_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olguser_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/olguser endpoint. */
    portal_targetsystem_olguser_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_olguser_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olguser_interactive_byid_get(UID_OLGUser: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
export interface portal_onelogin_mfa_poll_get_args {
    /** Factor identifier */ deviceid?: string;
}
export interface portal_onelogin_mfa_verifyotpwithverificationid_post_args {
    /** Factor identifier */ deviceid?: string;
}
export interface portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_olgapplication_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_olgapplication_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_olgrole_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_olgrole_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_olguser_get_args {
    /** Filters accounts for main and sub identities associated with the specified identity */ UID_PersonAssociated?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_olguser_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export declare class V2ApiClientMethodFactory {
    portal_OLGApplication_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_OLGApplication_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_OLGRole_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_OLGRole_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_onelogin_mfa_activate_post(/** Workflow action identifier */ workflowActionId: string, /** Factor identifier */ deviceid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<ActivateFactorData>;
    portal_onelogin_mfa_poll_get(/** Workflow action identifier */ workflowActionId: string, verificationid: string, options?: portal_onelogin_mfa_poll_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<VerifyPollingResult>;
    portal_onelogin_mfa_verifyotpwithverificationid_post(/** Workflow action identifier */ workflowActionId: string, verificationid: string, inputParameterName: string, options?: portal_onelogin_mfa_verifyotpwithverificationid_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<boolean>;
    portal_onelogin_mfa_factors_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<AuthFactors>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_olgapplication_get(options?: portal_targetsystem_olgapplication_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgapplication_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgapplication_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_olgapplication_datamodel_get(options?: portal_targetsystem_olgapplication_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_olgapplication_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olgapplication_interactive_byid_get(/** Primary key value UID_OLGApplication */ UID_OLGApplication: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olgrole_get(options?: portal_targetsystem_olgrole_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olgrole_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_olgrole_datamodel_get(options?: portal_targetsystem_olgrole_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_olgrole_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olgrole_interactive_byid_get(/** Primary key value UID_OLGRole */ UID_OLGRole: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olguser_get(options?: portal_targetsystem_olguser_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olguser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_olguser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_olguser_datamodel_get(options?: portal_targetsystem_olguser_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_olguser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_olguser_interactive_byid_get(/** Primary key value UID_OLGUser */ UID_OLGUser: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_OLGApplication_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGApplication_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_OLGRole_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_OLGRole_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Activates the given factor. */
    portal_onelogin_mfa_activate_post(/** Workflow action identifier */ workflowActionId: string, /** Factor identifier */ deviceid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<ActivateFactorData>;
    /** Waits for a confirmation of the factor. */
    portal_onelogin_mfa_poll_get(/** Workflow action identifier */ workflowActionId: string, verificationid: string, options?: portal_onelogin_mfa_poll_get_args, requestOptions?: ApiRequestOptions): Promise<VerifyPollingResult>;
    /** Verifies the supplied one-time password. */
    portal_onelogin_mfa_verifyotpwithverificationid_post(/** Workflow action identifier */ workflowActionId: string, verificationid: string, inputParameterName: string, options?: portal_onelogin_mfa_verifyotpwithverificationid_post_args, requestOptions?: ApiRequestOptions): Promise<boolean>;
    /** Returns the enrolled factors for the user. */
    portal_onelogin_mfa_factors_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<AuthFactors>;
    /** Returns a list of objects that can be assigned to the property UID_OLGApplication. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGApplication/UID_OLGApplication/candidates endpoint. */
    portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_OLGApplication_UID_OLGApplication_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OLGRole. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/OLGRole/UID_OLGRole/candidates endpoint. */
    portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_OLGRole_UID_OLGRole_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_olgapplication_get(options?: portal_targetsystem_olgapplication_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgapplication_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgapplication_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/olgapplication endpoint. */
    portal_targetsystem_olgapplication_datamodel_get(options?: portal_targetsystem_olgapplication_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_olgapplication_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olgapplication_interactive_byid_get(/** Primary key value UID_OLGApplication */ UID_OLGApplication: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olgrole_get(options?: portal_targetsystem_olgrole_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgrole_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olgrole_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/olgrole endpoint. */
    portal_targetsystem_olgrole_datamodel_get(options?: portal_targetsystem_olgrole_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_olgrole_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olgrole_interactive_byid_get(/** Primary key value UID_OLGRole */ UID_OLGRole: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olguser_get(options?: portal_targetsystem_olguser_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olguser_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_olguser_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/olguser endpoint. */
    portal_targetsystem_olguser_datamodel_get(options?: portal_targetsystem_olguser_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_olguser_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_olguser_interactive_byid_get(/** Primary key value UID_OLGUser */ UID_OLGUser: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
